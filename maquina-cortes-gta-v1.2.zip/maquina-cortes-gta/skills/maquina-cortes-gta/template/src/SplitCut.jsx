import React from 'react';
import {
  AbsoluteFill,
  Easing,
  Html5Audio,
  Img,
  Loop,
  OffthreadVideo,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';

const {fontFamily} = loadFont('normal', {weights: ['700', '800', '900'], subsets: ['latin']});

const W = 1080;
const H = 1920;
const TOP_H = H / 2; // metade de cima (streamer) e metade de baixo (vídeo)
const YELLOW = '#FFD400';
const FOLLOW = '#FF6A1A'; // botão "Seguir"
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'};

// Plano do streamer. Jump cut seco: o zoom só alterna entre 100% e 107% de um plano para o outro.
// O 1º plano e as viradas de seção (turns) entram com um punch-in curto que assenta no zoom do plano.
const Plane = ({index, turn, children}) => {
  const frame = useCurrentFrame();
  const base = index % 2 === 0 ? 1.0 : 1.07;
  const s = index === 0 || turn ? interpolate(frame, [0, 8], [base + 0.1, base], {...clamp, easing: Easing.out(Easing.cubic)}) : base;
  return <AbsoluteFill style={{transform: `scale(${s})`}}>{children}</AbsoluteFill>;
};

// Flash branco bem rápido, só nas viradas de seção; o swoosh toca junto, via props.sfx.
const Flash = () => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 5], [0.38, 0], clamp);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

// Sem `crop`: preenche a metade (cover) e usa `focus` para enquadrar.
// Com `crop` ({x, y, w, h} em pixels do vídeo de origem): amplia só essa região até preencher a metade.
const topVideoStyle = (crop, srcW, srcH, focus) => {
  if (!crop) {
    return {width: '100%', height: '100%', objectFit: 'cover', objectPosition: `${focus.x}% ${focus.y}%`};
  }
  const s = Math.max(W / crop.w, TOP_H / crop.h);
  return {
    position: 'absolute',
    width: srcW * s,
    height: srcH * s,
    left: -crop.x * s + (W - crop.w * s) / 2,
    top: -crop.y * s + (TOP_H - crop.h * s) / 2,
    objectFit: 'fill',
  };
};

const Top = ({segments, fps, sourceFile, focus, crop, srcW, srcH}) => {
  let offset = 0;
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: W, height: TOP_H, overflow: 'hidden', background: '#000'}}>
      {segments.map((seg, i) => {
        const frames = Math.max(1, Math.round((seg.to - seg.from) * fps));
        const start = Math.round(seg.from * fps);
        const from = offset;
        offset += frames;
        return (
          <Sequence key={i} from={from} durationInFrames={frames}>
            <Plane index={i} turn={seg.turn}>
              <OffthreadVideo src={staticFile(sourceFile)} startFrom={start} endAt={start + frames} style={topVideoStyle(crop, srcW, srcH, focus)} />
            </Plane>
            {seg.turn ? <Flash /> : null}
          </Sequence>
        );
      })}
    </div>
  );
};

const Bottom = ({file, start, duration, fps, total}) => {
  const startFrame = Math.round(start * fps);
  const available = Math.floor(duration * fps) - 2;
  const loopFrames = available >= 30 ? available : total;
  return (
    <div style={{position: 'absolute', left: 0, top: TOP_H, width: W, height: H - TOP_H, overflow: 'hidden', background: '#000'}}>
      <Loop durationInFrames={loopFrames}>
        <OffthreadVideo src={staticFile(file)} startFrom={startFrame} endAt={startFrame + loopFrames} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} />
      </Loop>
    </div>
  );
};

// Área de cada metade para os popups.
const AREA = {
  cima: {top: 60, height: TOP_H - 220},
  baixo: {top: TOP_H + 150, height: H - TOP_H - 300},
};

// Saída comum dos popups: fade nos últimos 6 quadros.
const useOut = (durationInFrames) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [durationInFrames - 6, durationInFrames], [1, 0], clamp);
};

// Foto/print/arte: cartão com borda branca, entra com escala 0,9 → 1 e um leve balanço.
const PhotoPop = ({file, onde, durationInFrames}) => {
  const frame = useCurrentFrame();
  const inn = interpolate(frame, [0, 8], [0, 1], {...clamp, easing: Easing.out(Easing.back(1.6))});
  const out = useOut(durationInFrames);
  const a = AREA[onde] || AREA.baixo;
  return (
    <div style={{position: 'absolute', left: 0, width: W, ...a, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: Math.min(inn, out), transform: `scale(${0.9 + 0.1 * inn})`}}>
      <Img src={staticFile(file)} style={{maxWidth: 820, maxHeight: a.height, objectFit: 'contain', borderRadius: 26, border: '6px solid #fff', boxShadow: '0 18px 48px rgba(0,0,0,0.55)'}} />
    </div>
  );
};

// Logo com fundo transparente vindo em direção à tela: 0,35× → 1× com aceleração, segura, e passa da tela (1,6×) sumindo.
const LogoPop = ({file, onde, durationInFrames}) => {
  const frame = useCurrentFrame();
  const a = AREA[onde] || AREA.cima;
  const exitStart = Math.max(10, durationInFrames - 7);
  const grow = interpolate(frame, [0, 9], [0.35, 1], {...clamp, easing: Easing.in(Easing.quad)});
  const pass = interpolate(frame, [exitStart, durationInFrames], [1, 1.6], {...clamp, easing: Easing.in(Easing.cubic)});
  const o = Math.min(interpolate(frame, [0, 4], [0, 1], clamp), interpolate(frame, [exitStart, durationInFrames], [1, 0], clamp));
  return (
    <div style={{position: 'absolute', left: 0, width: W, ...a, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: o, transform: `scale(${grow * pass})`}}>
      <Img src={staticFile(file)} style={{maxWidth: 760, maxHeight: a.height * 0.85, objectFit: 'contain', filter: 'drop-shadow(0 14px 30px rgba(0,0,0,0.6))'}} />
    </div>
  );
};

// Comparação lado a lado (ex.: mapa do GTA 5 | mapa do GTA 6), cada um com o rótulo embaixo. O 2º entra 6 quadros depois.
const ComparePop = ({files, labels, onde, durationInFrames}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = useOut(durationInFrames);
  const a = AREA[onde] || AREA.baixo;
  return (
    <div style={{position: 'absolute', left: 0, width: W, ...a, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 28, opacity: out}}>
      {files.slice(0, 2).map((f, i) => {
        const s = spring({frame: frame - i * 6, fps, config: {damping: 14, stiffness: 180}});
        return (
          <div key={f} style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, transform: `translateY(${(1 - s) * 80}px) scale(${0.85 + 0.15 * s})`, opacity: s}}>
            <Img src={staticFile(f)} style={{width: 470, height: a.height - 120, objectFit: 'cover', borderRadius: 22, border: '6px solid #fff', boxShadow: '0 16px 40px rgba(0,0,0,0.55)'}} />
            {labels[i] ? (
              <span style={{fontFamily, fontWeight: 900, fontSize: 54, color: '#fff', textTransform: 'uppercase', WebkitTextStroke: '9px #000', paintOrder: 'stroke fill'}}>{labels[i]}</span>
            ) : null}
          </div>
        );
      })}
    </div>
  );
};

const Popup = ({im, durationInFrames}) => {
  if (im.tipo === 'logo') return <LogoPop file={im.files[0]} onde={im.onde} durationInFrames={durationInFrames} />;
  if (im.tipo === 'comparar') return <ComparePop files={im.files} labels={im.labels} onde={im.onde} durationInFrames={durationInFrames} />;
  return <PhotoPop file={im.files[0]} onde={im.onde} durationInFrames={durationInFrames} />;
};

// Legenda palavra por palavra na divisa. A palavra falada fica colorida e cresce um pouco; nos intervalos entre
// palavras, a última dita continua acesa (não pisca branco).
const Captions = ({pages, fps, color}) => {
  const frame = useCurrentFrame();
  const ms = (frame / fps) * 1000;
  const page = pages.find((p) => ms >= p.startMs && ms < p.endMs);
  if (!page) return null;
  let active = -1;
  page.words.forEach((w, i) => {
    if (ms >= w.startMs) active = i;
  });
  return (
    <div
      style={{
        position: 'absolute',
        left: 40,
        width: W - 80,
        top: TOP_H,
        transform: 'translateY(-50%)',
        textAlign: 'center',
        fontFamily,
        fontWeight: 900,
        fontSize: 96,
        lineHeight: 1.04,
        textTransform: 'uppercase',
        color: '#fff',
        WebkitTextStroke: '11px #000',
        paintOrder: 'stroke fill',
        textShadow: '0 7px 0 rgba(0,0,0,0.35)',
      }}
    >
      {page.words.map((w, i) => {
        const on = i === active;
        const pop = on ? interpolate(ms - w.startMs, [0, 90], [1.14, 1.06], clamp) : 1;
        return (
          <span key={i} style={{color: on ? color : '#fff', display: 'inline-block', margin: '0 12px', transform: `scale(${pop})`}}>
            {w.text}
          </span>
        );
      })}
    </div>
  );
};

// Marca d'água: logo circular à esquerda e o nome do perfil ao lado, no canto superior direito.
const Watermark = ({logo, name}) => (
  <div style={{position: 'absolute', top: 150, right: 40, display: 'flex', alignItems: 'center', gap: 14}}>
    <Img src={staticFile(logo)} style={{width: 104, height: 104, borderRadius: '50%', objectFit: 'cover', border: '4px solid #fff', boxShadow: '0 6px 18px rgba(0,0,0,0.45)'}} />
    <span style={{fontFamily, fontWeight: 900, fontSize: 40, textTransform: 'uppercase', color: '#fff', WebkitTextStroke: '7px #14002a', paintOrder: 'stroke fill', textShadow: '0 4px 0 rgba(60,0,90,0.6)'}}>{name}</span>
  </div>
);

// Cursor (seta) desenhado em SVG.
const Cursor = ({style}) => (
  <svg width="64" height="64" viewBox="0 0 24 24" style={style}>
    <path d="M4 2 L4 19 L8.5 15 L11.5 21.5 L14.2 20.3 L11.3 13.9 L17.5 13.9 Z" fill="#fff" stroke="#000" strokeWidth="1.4" strokeLinejoin="round" />
  </svg>
);

// Final "Seguir → Seguindo": pílula branca com o avatar e o nome do perfil; o cursor entra, clica no botão
// laranja "Seguir" (aos ~1,25 s) e ele vira "Seguindo ✓". Ocupa os últimos `seconds` do corte, na metade de baixo.
const FollowEnd = ({logo, name, durationInFrames}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const click = Math.round(1.25 * fps);
  const enter = spring({frame, fps, config: {damping: 13, stiffness: 160}});
  const leave = interpolate(frame, [durationInFrames - 6, durationInFrames], [1, 0], clamp);
  const press = interpolate(frame, [click - 2, click, click + 4], [1, 0.9, 1], clamp);
  const done = frame >= click;
  // cursor: vem de baixo à direita até o botão, aperta e sai
  const cx = interpolate(frame, [8, click - 2], [980, 742], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const cy = interpolate(frame, [8, click - 2], [430, 92], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const cOut = interpolate(frame, [click + 10, click + 18], [1, 0], clamp);
  const pillW = 860;
  return (
    <div style={{position: 'absolute', left: (W - pillW) / 2, top: TOP_H + 330, width: pillW, height: 520, opacity: leave}}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 40,
          width: pillW,
          height: 150,
          borderRadius: 75,
          background: '#fff',
          boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          padding: '0 18px',
          gap: 22,
          transform: `scale(${0.6 + 0.4 * enter})`,
          opacity: enter,
        }}
      >
        <Img src={staticFile(logo)} style={{width: 114, height: 114, borderRadius: '50%', objectFit: 'cover'}} />
        <span style={{flex: 1, fontFamily, fontWeight: 800, fontSize: 44, color: '#111', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis'}}>{String(name).replace(/^@/, '')}</span>
        <div
          style={{
            height: 96,
            padding: '0 34px',
            borderRadius: 48,
            display: 'flex',
            alignItems: 'center',
            fontFamily,
            fontWeight: 800,
            fontSize: 40,
            background: done ? '#E6E6E6' : FOLLOW,
            color: done ? '#333' : '#fff',
            transform: `scale(${press})`,
          }}
        >
          {done ? 'Seguindo ✓' : 'Seguir'}
        </div>
      </div>
      <Cursor style={{position: 'absolute', left: cx, top: cy, opacity: Math.min(enter, cOut), transform: `scale(${press})`}} />
    </div>
  );
};

export const SplitCut = (props) => {
  const {fps} = useVideoConfig();
  const total = Math.max(1, Math.round(props.totalSeconds * fps));
  const outroFrames = props.outro ? Math.min(total, Math.round(props.outro.seconds * fps)) : 0;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Top segments={props.segments} fps={fps} sourceFile={props.sourceFile} focus={props.focus} crop={props.crop} srcW={props.sourceWidth} srcH={props.sourceHeight} />
      <Bottom file={props.bottomFile} start={props.bottomStart} duration={props.bottomDuration} fps={fps} total={total} />
      {(props.images || []).map((im, i) => {
        const frames = Math.max(12, Math.round(im.dur * fps));
        return (
          <Sequence key={`img${i}`} from={Math.round(im.at * fps)} durationInFrames={frames}>
            <Popup im={im} durationInFrames={frames} />
          </Sequence>
        );
      })}
      <div style={{position: 'absolute', left: 0, width: W, top: TOP_H - 170, height: 340, background: 'linear-gradient(180deg, rgba(0,0,0,0), rgba(0,0,0,0.62) 50%, rgba(0,0,0,0))'}} />
      <Captions pages={props.pages} fps={fps} color={(props.caption && props.caption.color) || YELLOW} />
      <Watermark logo={props.watermark.logo} name={props.watermark.name} />
      {outroFrames ? (
        <Sequence from={total - outroFrames} durationInFrames={outroFrames}>
          <FollowEnd logo={props.watermark.logo} name={props.watermark.name} durationInFrames={outroFrames} />
        </Sequence>
      ) : null}
      {(props.sfx || []).map((s, i) => (
        <Sequence key={`sfx${i}`} from={Math.max(0, Math.round(s.at * fps))} durationInFrames={Math.round(3 * fps)}>
          <Html5Audio src={staticFile(s.file)} volume={s.volume} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
