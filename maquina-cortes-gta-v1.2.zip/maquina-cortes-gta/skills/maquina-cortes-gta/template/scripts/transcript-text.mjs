#!/usr/bin/env node
// Imprime a transcrição para o Claude ler sem despejar o JSON.
//
//   node transcript-text.mjs <pasta>                       frases: "[mm:ss.s] frase" (pausas longas marcadas)
//   node transcript-text.mjs <pasta> --de 300 --ate 360    só esse trecho (segundos ou mm:ss)
//   node transcript-text.mjs <pasta> --de 300 --ate 330 --palavras
//                                                          palavra por palavra, com o segundo exato de cada uma
//                                                          (para acertar o início do gancho e o fim do payoff)
// Se existir <pasta>/heatmap.json (do mais-reproduzido.mjs), as frases dentro de um pico levam "[PICO n]".
import fs from 'node:fs';
import path from 'node:path';
import {mmss, sec} from './timeline.mjs';

const args = process.argv.slice(2);
const work = args[0];
if (!work) {
  console.error('Uso: node transcript-text.mjs <pasta_de_trabalho> [--de S] [--ate S] [--palavras]');
  process.exit(1);
}
const opt = (n) => {
  const i = args.indexOf(n);
  if (i < 0) return undefined;
  const v = args[i + 1];
  if (/^\d+:\d+(\.\d+)?$/.test(v)) {
    const [m, s] = v.split(':');
    return Number(m) * 60 + Number(s);
  }
  return Number(v);
};
const from = opt('--de') ?? 0;
const to = opt('--ate') ?? Infinity;
const words = JSON.parse(fs.readFileSync(path.join(work, 'captions.json'), 'utf8')).filter((w) => sec(w.startMs) >= from && sec(w.startMs) < to);

let peaks = [];
try {
  peaks = JSON.parse(fs.readFileSync(path.join(work, 'heatmap.json'), 'utf8')).picos || [];
} catch {
  /* sem heatmap */
}
const peakTag = (t) => {
  const k = peaks.findIndex((p) => t >= p.inicio - 5 && t <= p.fim + 5);
  return k >= 0 ? ` [PICO ${k + 1}]` : '';
};

if (args.includes('--palavras')) {
  for (const w of words) console.log(`${sec(w.startMs).toFixed(2)}–${sec(w.endMs).toFixed(2)}  ${w.text}`);
  process.exit(0);
}

let line = [];
let lineStart = 0;
const flush = () => {
  if (line.length) console.log(`[${mmss(lineStart)}]${peakTag(lineStart)} ${line.join(' ')}`);
  line = [];
};
words.forEach((w, i) => {
  const prev = words[i - 1];
  const gap = prev ? sec(w.startMs - prev.endMs) : 0;
  if (line.length && gap > 0.9) {
    flush();
    if (gap > 2) console.log(`   (pausa de ${gap.toFixed(1)} s)`);
  }
  if (!line.length) lineStart = sec(w.startMs);
  line.push(w.text);
  if (/[.!?…]$/.test(w.text) || line.length >= 28) flush();
});
flush();
