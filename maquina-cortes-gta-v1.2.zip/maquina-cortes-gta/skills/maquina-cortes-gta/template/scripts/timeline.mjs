// Lógica da linha do tempo dos cortes, sem efeitos colaterais (dá para testar e reaproveitar).
// Usada pelo build.mjs (render) e pelo conferir-cortes.mjs (conferência antes do render).
// Tempos em segundos, a não ser onde o nome diz Ms.

const END_OF_PHRASE = /[.!?…]["”')\]]*$/;
export const sec = (ms) => ms / 1000;

// Última palavra que começa antes de `t`.
function wordBefore(words, t) {
  let found = null;
  for (const w of words) {
    if (sec(w.startMs) < t) found = w;
    else break;
  }
  return found;
}

// Encaixa o início e o fim do corte nas palavras: começa ~0,15 s antes da 1ª palavra do gancho (sem pegar o fim
// da palavra anterior) e termina ~0,25 s depois da última palavra (sem pegar o começo da seguinte).
export function snapClip(words, start, end) {
  const i = words.findIndex((w) => sec(w.startMs) >= start - 0.25);
  if (i < 0) return {start, end, first: -1, last: -1};
  let j = -1;
  for (let k = i; k < words.length && sec(words[k].startMs) < end; k++) j = k;
  if (j < i) return {start, end, first: -1, last: -1};
  const firstStart = sec(words[i].startMs);
  const prevEnd = i > 0 ? sec(words[i - 1].endMs) : 0;
  const s = Math.max(0, firstStart - 0.15, Math.min(prevEnd + 0.02, firstStart - 0.02));
  const lastEnd = sec(words[j].endMs);
  const nextStart = j + 1 < words.length ? sec(words[j + 1].startMs) : Infinity;
  const e = Math.max(lastEnd, Math.min(lastEnd + 0.25, nextStart - 0.02));
  return {start: s, end: e, first: i, last: j};
}

// Tira as pausas. Entre frases (palavra anterior termina em . ! ? …), pausa a partir de `minSilence` fica com
// `keep` segundos. Dentro da frase, só sai pausa a partir de `longSilence` (hesitação longa). Nenhum trecho
// com fala é descartado, por menor que seja.
export function segmentsFor(words, silences, start, end, {minSilence = 0.3, keep = 0.2, longSilence = 0.8} = {}) {
  const pad = keep / 2;
  const segs = [];
  let cursor = start;
  for (const s of silences) {
    const a = Math.max(s.start, start);
    const b = Math.min(s.end, end);
    if (b - a < minSilence) continue;
    const prev = wordBefore(words, s.start + 0.05);
    const betweenPhrases = !prev || END_OF_PHRASE.test(prev.text);
    if (!betweenPhrases && b - a < longSilence) continue;
    const cutFrom = a === start ? start : a + pad; // pausa no começo do corte sai inteira
    const cutTo = b === end ? end : b - pad; // e no fim também
    if (cutTo - cutFrom < 0.08) continue;
    if (cutFrom > cursor + 0.01) segs.push({from: cursor, to: cutFrom});
    cursor = Math.max(cursor, cutTo);
  }
  if (end > cursor + 0.01) segs.push({from: cursor, to: end});
  return segs.length ? segs : [{from: start, to: end}];
}

// Jump cuts: quebra planos longos a cada ~`every` s, sempre no começo de uma palavra. Não tira conteúdo.
export function splitSegs(words, segs, every) {
  if (!every) return segs.map((s) => ({...s}));
  const out = [];
  for (const s of segs) {
    const starts = words.map((w) => sec(w.startMs)).filter((t) => t > s.from + 1 && t < s.to - 1);
    let cursor = s.from;
    while (s.to - cursor > every * 1.5) {
      const target = cursor + every;
      const cand = starts.filter((t) => t > cursor + 1.2).sort((a, b) => Math.abs(a - target) - Math.abs(b - target))[0];
      if (!cand) break;
      out.push({from: cursor, to: cand});
      cursor = cand;
    }
    out.push({from: cursor, to: s.to});
  }
  return out;
}

// Marca as viradas de seção (`turns`, em segundos do vídeo de origem). Se a virada cai perto (< 0,4 s) de um
// corte que já existe, usa esse corte; se cai numa pausa removida, usa o plano seguinte; senão, abre um corte
// novo no começo de palavra mais próximo.
export function applyTurns(words, segs, turns = [], legacy = false) {
  const out = segs.map((s) => ({...s, turn: false}));
  const nearestWord = (t) => {
    let best = t;
    let d = 0.4;
    for (const w of words) {
      const x = sec(w.startMs);
      if (Math.abs(x - t) < d) {
        d = Math.abs(x - t);
        best = x;
      }
    }
    return best;
  };
  for (const t0 of turns) {
    let k = out.findIndex((x) => t0 >= x.from && t0 < x.to);
    if (k < 0) {
      k = out.findIndex((x) => x.from >= t0);
      if (k > 0) out[k].turn = true;
      continue;
    }
    const seg = out[k];
    if (t0 - seg.from < 0.4) {
      if (k > 0) seg.turn = true;
    } else if (seg.to - t0 < 0.4) {
      if (k + 1 < out.length) out[k + 1].turn = true;
    } else {
      const t = nearestWord(t0);
      if (t - seg.from < 0.3 || seg.to - t < 0.3) continue;
      out.splice(k, 1, {from: seg.from, to: t, turn: seg.turn}, {from: t, to: seg.to, turn: true});
    }
  }
  if (legacy) out.forEach((s, i) => (s.turn = i > 0));
  out[0].turn = false;
  return out;
}

// Linha do tempo nova, em quadros inteiros (a mesma conta do SplitCut.jsx).
export function mapTimeline(segs, fps) {
  let frames = 0;
  const mapped = segs.map((s) => {
    const n = Math.max(1, Math.round((s.to - s.from) * fps));
    const m = {...s, outStart: frames / fps, outEnd: (frames + n) / fps};
    frames += n;
    return m;
  });
  return {mapped, total: frames / fps};
}

// Segundo do vídeo de origem → segundo do corte. Um tempo dentro de uma pausa removida vai para o plano seguinte.
export function toOut(mapped, t) {
  const m = mapped.find((x) => t >= x.from && t < x.to);
  if (m) return m.outStart + (t - m.from);
  const next = mapped.find((x) => x.from >= t);
  if (next) return next.outStart;
  return mapped.length ? mapped[mapped.length - 1].outEnd : 0;
}

// Palavras na linha do tempo do corte.
export function remapWords(words, mapped) {
  const out = [];
  for (const w of words) {
    const ws = sec(w.startMs);
    const seg = mapped.find((s) => ws >= s.from - 0.02 && ws < s.to);
    if (!seg) continue;
    const o = seg.outStart + Math.max(0, ws - seg.from);
    const oe = Math.min(seg.outEnd, o + Math.max(0.12, sec(w.endMs - w.startMs)));
    out.push({text: w.text, startMs: Math.round(o * 1000), endMs: Math.round(oe * 1000)});
  }
  return out;
}

// Agrupa as palavras em páginas de legenda (até `maxWords` palavras e `maxChars` letras).
export function makePages(list, {maxWords = 3, maxChars = 20} = {}) {
  const pages = [];
  let cur = [];
  const flush = () => {
    if (cur.length) pages.push({words: cur, startMs: cur[0].startMs, endMs: cur[cur.length - 1].endMs});
    cur = [];
  };
  for (const w of list) {
    const gap = cur.length ? w.startMs - cur[cur.length - 1].endMs : 0;
    const chars = cur.reduce((n, x) => n + x.text.length, 0) + w.text.length;
    if (cur.length >= maxWords || chars > maxChars || gap > 600) flush();
    cur.push(w);
    if (END_OF_PHRASE.test(w.text)) flush();
  }
  flush();
  pages.forEach((p, i) => {
    const next = pages[i + 1];
    p.endMs = Math.min(next ? next.startMs : Infinity, p.endMs + 250);
    p.words = p.words.map((w) => ({...w, text: w.text.replace(/[,;:]+$/, '')}));
  });
  return pages;
}

// Palavras de aquecimento que não devem abrir um corte.
export const FILLERS = ['então', 'entao', 'galera', 'bom', 'tipo', 'né', 'ne', 'é', 'e aí', 'enfim', 'beleza', 'olha', 'cara', 'mano', 'voltando', 'assim', 'ah', 'eh', 'hum', 'bem'];
export const norm = (s) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
export const mmss = (t) => {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${String(m).padStart(2, '0')}:${s.toFixed(1).padStart(4, '0')}`;
};
