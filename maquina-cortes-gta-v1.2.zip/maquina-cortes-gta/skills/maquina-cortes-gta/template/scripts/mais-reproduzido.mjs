#!/usr/bin/env node
// Lê o gráfico "Mais reproduzidos" (heatmap) de um vídeo do YouTube pelo yt-dlp, sem navegador.
// Uso: node mais-reproduzido.mjs "<link do YouTube>" <pasta_de_trabalho> [quantos_picos]
// Grava <pasta>/heatmap.json e imprime os picos (do mais forte para o mais fraco). O transcript-text.mjs
// marca as frases que caem num pico. Nem todo vídeo tem o gráfico (vídeo novo ou com poucas visualizações).
import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {mmss} from './timeline.mjs';

const [url, work, nArg] = process.argv.slice(2);
if (!url || !work) {
  console.error('Uso: node mais-reproduzido.mjs "<link do YouTube>" <pasta_de_trabalho> [quantos_picos]');
  process.exit(1);
}
const n = Number(nArg || 5);
const r = spawnSync('yt-dlp', ['-J', '--skip-download', '--no-playlist', '--no-warnings', url], {encoding: 'utf8', maxBuffer: 64 * 1024 * 1024});
if (r.error || r.status !== 0) {
  console.error(`O yt-dlp não conseguiu ler o vídeo: ${(r.stderr || r.error?.message || '').trim().split('\n').pop()}`);
  process.exit(1);
}
const info = JSON.parse(r.stdout);
const heat = (info.heatmap || []).map((h) => ({inicio: h.start_time, fim: h.end_time, valor: h.value}));
if (!heat.length) {
  console.log('Este vídeo não tem o gráfico "Mais reproduzidos". Siga só pela transcrição.');
  process.exit(2);
}

// picos: máximos locais, sem os 3% iniciais (o começo é sempre alto), a pelo menos 45 s um do outro
const dur = info.duration || heat[heat.length - 1].fim;
const cand = heat
  .map((h, i) => ({...h, i}))
  .filter((h) => h.inicio > dur * 0.03)
  .filter((h) => h.valor >= (heat[h.i - 1]?.valor ?? 0) && h.valor >= (heat[h.i + 1]?.valor ?? 0))
  .sort((a, b) => b.valor - a.valor);
const picos = [];
for (const c of cand) {
  if (picos.length >= n) break;
  if (picos.some((p) => Math.abs(p.inicio - c.inicio) < 45)) continue;
  // alarga o pico enquanto os vizinhos ficam acima de 80% dele
  let a = c.i;
  let b = c.i;
  while (a > 0 && heat[a - 1].valor >= c.valor * 0.8) a--;
  while (b < heat.length - 1 && heat[b + 1].valor >= c.valor * 0.8) b++;
  picos.push({inicio: heat[a].inicio, fim: heat[b].fim, valor: Number(c.valor.toFixed(3))});
}
fs.mkdirSync(work, {recursive: true});
fs.writeFileSync(path.join(work, 'heatmap.json'), JSON.stringify({duracao: dur, picos, pontos: heat}, null, 2));
picos.forEach((p, k) => console.log(`PICO ${k + 1}: ${mmss(p.inicio)} a ${mmss(p.fim)} (intensidade ${p.valor})`));
