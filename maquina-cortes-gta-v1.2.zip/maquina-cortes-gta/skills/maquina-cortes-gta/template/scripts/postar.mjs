#!/usr/bin/env node
// Posta um corte no YouTube (Shorts), no TikTok e no Instagram (Reels) pelo Postiz (CLI "postiz").
// As redes e os ajustes ficam em ~/.maquina-cortes-gta/automatico.json ("redes" e "ajustes").
//
//   node postar.mjs --conferir                      confere o login e mostra as regras de cada rede configurada
//   node postar.mjs <video.mp4> "Título" ["descrição"] [--rede youtube] [--quando 2026-11-20T18:00:00Z]
//                                                   posta agora (+2 min) ou na data dada
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {runBinAsync} from './bin.mjs';

const HOME = path.join(os.homedir(), '.maquina-cortes-gta');
const postiz = (args) => runBinAsync('postiz', 'postiz', args, {timeoutMs: 15 * 60e3});

export function loadAuto() {
  try {
    return JSON.parse(fs.readFileSync(path.join(HOME, 'automatico.json'), 'utf8'));
  } catch {
    return {};
  }
}

// Ajustes padrão de cada rede. O que o Postiz exigir a mais vai em "ajustes" no automatico.json
// (veja com --conferir). TikTok: DIRECT_POST publica; "UPLOAD" só deixa na caixa de entrada do app.
const DEFAULTS = {
  youtube: (t) => ({title: t.slice(0, 100), type: 'public'}),
  tiktok: () => ({privacy_level: 'PUBLIC_TO_EVERYONE', duet: false, stitch: false, comment: true, content_posting_method: 'DIRECT_POST'}),
  instagram: () => ({post_type: 'post'}),
};

function caption(rede, {titulo, descricao, credito}, cfg) {
  const tags = (cfg.hashtags ?? ['#gta6', '#gta', '#shorts']).join(' ');
  const parts = rede === 'youtube' ? [descricao] : [titulo, descricao];
  if (credito) parts.push(`Créditos: ${credito}`);
  parts.push(tags);
  return parts.filter(Boolean).join('\n\n');
}

// Devolve [{rede, ok, erro?}]
export async function postClip({video, titulo, descricao = '', credito = '', quando = new Date(Date.now() + 2 * 60e3), redes, cfg = loadAuto(), log = console.log}) {
  const alvo = Object.entries(cfg.redes || {}).filter(([r, id]) => id && (!redes || redes.includes(r)));
  if (!alvo.length) return [{rede: '-', ok: false, erro: 'nenhuma rede em "redes" no automatico.json'}];
  const up = await postiz(['upload', video]);
  let url;
  try {
    url = JSON.parse(up.out).path;
  } catch {
    /* sem json */
  }
  if (!up.ok || !url) return [{rede: '-', ok: false, erro: `upload falhou: ${up.err || up.out}`.slice(0, 300)}];
  const out = [];
  for (const [rede, id] of alvo) {
    const settings = {...(DEFAULTS[rede]?.(titulo) || {}), ...(cfg.ajustes?.[rede] || {})};
    const r = await postiz(['posts:create', '-c', caption(rede, {titulo, descricao, credito}, cfg), '-s', quando.toISOString(), '-m', url, '-i', id, '--settings', JSON.stringify(settings)]);
    out.push({rede, ok: r.ok, erro: r.ok ? undefined : (r.err || r.out).slice(0, 300)});
    log(`${r.ok ? 'agendado' : 'FALHOU'} ${rede} ${quando.toISOString()} ${titulo}${r.ok ? '' : ' :: ' + (r.err || r.out).slice(0, 200)}`);
  }
  return out;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const cfg = loadAuto();
  if (args[0] === '--conferir') {
    const a = await postiz(['auth:status']);
    console.log(a.ok ? 'Postiz: logado.' : `Postiz: NÃO logado (${a.err || a.out}). Rode: postiz auth:login`);
    if (!a.ok) process.exit(1);
    console.log('\nContas conectadas no Postiz:\n' + (await postiz(['integrations:list'])).out);
    for (const [rede, id] of Object.entries(cfg.redes || {})) {
      if (!id) continue;
      const s = await postiz(['integrations:settings', id]);
      console.log(`\n=== ${rede} (${id}) ===\n${s.ok ? s.out : 'erro: ' + s.err}`);
    }
    process.exit(0);
  }
  const [video, titulo, descricao] = args.filter((x, i) => !x.startsWith('--') && !args[i - 1]?.startsWith('--'));
  if (!video || !titulo || !fs.existsSync(video)) {
    console.error('Uso: node postar.mjs <video.mp4> "Título" ["descrição"] [--rede youtube] [--quando ISO]  |  node postar.mjs --conferir');
    process.exit(1);
  }
  const opt = (n) => (args.includes(n) ? args[args.indexOf(n) + 1] : undefined);
  const res = await postClip({video, titulo, descricao, redes: opt('--rede')?.split(','), quando: opt('--quando') ? new Date(opt('--quando')) : undefined, cfg});
  process.exit(res.every((r) => r.ok) ? 0 : 1);
}
