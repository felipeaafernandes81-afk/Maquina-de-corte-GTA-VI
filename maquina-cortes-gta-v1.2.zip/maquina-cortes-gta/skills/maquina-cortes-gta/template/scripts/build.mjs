#!/usr/bin/env node
// Monta e renderiza os cortes: encaixa início e fim nas palavras, tira as pausas, ajusta as legendas à nova
// linha do tempo e roda o Remotion.
// Uso: node scripts/build.mjs <pasta_de_trabalho> <pasta_de_saida> [id_do_corte ...]
// A pasta de trabalho precisa ter: source.mp4, bottom.mp4, captions.json, silences.json, meta.json, cuts.json.
// Passe ids no fim para renderizar só alguns cortes (ex.: refazer um que falhou).
import {execFileSync, spawnSync} from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {searchImages} from './buscar-imagens.mjs';
import {applyTurns, makePages, mapTimeline, remapWords, segmentsFor, snapClip, splitSegs, toOut} from './timeline.mjs';

const [work, outDir, ...only] = process.argv.slice(2);
if (!work || !outDir) {
  console.error('Uso: node scripts/build.mjs <pasta_de_trabalho> <pasta_de_saida> [id_do_corte ...]');
  process.exit(1);
}
const FPS = 30;
const HOME = path.join(os.homedir(), '.maquina-cortes-gta');
const ENGINE = path.join(HOME, 'engine');
const fail = (msg) => {
  console.error(msg);
  process.exit(1);
};

let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(path.join(HOME, 'config.json'), 'utf8'));
} catch {
  fail(`Não achei ${path.join(HOME, 'config.json')}. Rode o setup.mjs (e grave o perfil) antes do build.`);
}
if (!cfg.logo || !fs.existsSync(path.join(HOME, cfg.logo)) || !cfg.profileName) {
  fail('Perfil incompleto (nome ou logo). Rode: node setup.mjs --profile "NOME" --logo "CAMINHO/DA/LOGO.png"');
}
for (const f of ['source.mp4', 'bottom.mp4', 'captions.json', 'silences.json', 'meta.json', 'cuts.json']) {
  if (!fs.existsSync(path.join(work, f))) {
    fail(
      f === 'bottom.mp4'
        ? 'Falta work/bottom.mp4 (o vídeo da metade de baixo). Baixe o trailer oficial ou o vídeo que o usuário mandou.'
        : `Falta ${path.join(work, f)}. Rode o transcribe.mjs e grave o cuts.json antes.`,
    );
  }
}
const read = (f) => JSON.parse(fs.readFileSync(path.join(work, f), 'utf8'));
const words = read('captions.json');
const silences = read('silences.json');
const cuts = read('cuts.json');
const meta = read('meta.json');
fs.mkdirSync(outDir, {recursive: true});

// logo na pasta pública do render
const logoName = `wm-${cfg.logo}`;
fs.copyFileSync(path.join(HOME, cfg.logo), path.join(work, logoName));

const probeDur = (f) =>
  Number(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f], {encoding: 'utf8'}).trim());
const bottomTotal = probeDur(path.join(work, 'bottom.mp4'));
const sourceTotal = probeDur(path.join(work, 'source.mp4'));

// efeitos sonoros (opcionais) em ~/.maquina-cortes-gta/sfx
const sfxDir = path.join(HOME, 'sfx');
const sfxFile = (name) => {
  const f = ['.mp3', '.wav'].map((e) => path.join(sfxDir, name + e)).find((p) => fs.existsSync(p));
  if (!f) return null;
  const dst = `sfx-${name}${path.extname(f)}`;
  fs.copyFileSync(f, path.join(work, dst));
  return dst;
};
const SFX = {impacto: sfxFile('impacto'), whoosh: sfxFile('whoosh'), pop: sfxFile('pop'), clique: sfxFile('clique') || sfxFile('pop')};
const gain = cfg.sfxGain ?? 0.6; // volume geral dos efeitos (bem abaixo da voz)

// pega uma imagem: arquivo do usuário ou busca no Google (API oficial)
async function imageSource(spec, tag) {
  if (spec.file) {
    if (fs.existsSync(spec.file)) return spec.file;
    console.warn(`Imagem ignorada: não achei o arquivo ${spec.file}.`);
    return null;
  }
  if (!spec.query) return null;
  try {
    const [src] = await searchImages(spec.query, path.join(work, 'imgs'), 1, tag);
    if (!src) console.warn(`Imagem "${spec.query}" ignorada: a busca não trouxe nenhuma imagem utilizável.`);
    return src || null;
  } catch (e) {
    console.warn(`Imagem "${spec.query}" ignorada: ${e.message}. Opções: GOOGLE_API_KEY e GOOGLE_CSE_ID, mandar o arquivo ("file") ou seguir sem ela.`);
    return null;
  }
}

const safeId = (id, i) => String(id || `corte-${i + 1}`).replace(/[^\p{L}\p{N}_-]+/gu, '-').slice(0, 80);
const results = [];
for (const [idx, clip] of cuts.clips.entries()) {
  const id = safeId(clip.id, idx);
  if (only.length && !only.includes(id) && !only.includes(clip.id)) continue;
  if (!(clip.end > clip.start)) {
    console.error(`${id}: "end" precisa ser maior que "start". Pulei.`);
    results.push({id, ok: false, erro: 'start/end inválidos'});
    continue;
  }

  // 1) início e fim encaixados nas palavras
  const snapped = snapClip(words, Math.max(0, clip.start), Math.min(sourceTotal, clip.end));
  const start = snapped.start;
  const end = Math.min(sourceTotal, snapped.end);

  // 2) pausas e jump cuts
  //   ritmo padrão: jump cut seco a cada ~2,8 s (o zoom alterna 100% ↔ 107%, sem flash nem swoosh)
  //   "normal": só tira as pausas · "rapido": estilo antigo, flash + swoosh em todo corte (não recomendado)
  //   turns: segundos (do vídeo de origem) das viradas de seção; só nelas entram flash e swoosh
  const legacy = clip.ritmo === 'rapido';
  const every = clip.ritmo === 'normal' ? 0 : clip.cutEvery ?? (legacy ? 3.2 : 2.8);
  const pausas = {minSilence: cfg.pausaMinima ?? 0.3, keep: cfg.pausaFica ?? 0.2, longSilence: cfg.pausaLongaNaFrase ?? 0.8};
  const segs = applyTurns(words, splitSegs(words, segmentsFor(words, silences, start, end, pausas), every), clip.turns || [], legacy);
  const {mapped, total} = mapTimeline(segs, FPS);

  // 3) legendas na linha do tempo nova
  const remapped = remapWords(words, mapped).map((w) => ({...w, text: w.text.toUpperCase()}));

  // 4) imagens
  const images = [];
  for (const [k, im] of (clip.images || []).entries()) {
    const tipo = im.tipo || (im.files || im.queries ? 'comparar' : 'foto');
    const specs = tipo === 'comparar' ? (im.files || im.queries || []).map((x) => (im.files ? {file: x} : {query: x})) : [im];
    const files = [];
    for (const [n, spec] of specs.entries()) {
      const src = await imageSource(spec, `${id}-${k}-${n}`);
      if (!src) continue;
      const dst = `img-${id}-${k}-${n}${path.extname(src)}`;
      fs.copyFileSync(src, path.join(work, dst));
      files.push(dst);
    }
    if (!files.length || (tipo === 'comparar' && files.length < 2)) continue;
    const dur = Math.max(0.6, im.dur ?? (tipo === 'comparar' ? 3 : 2.2));
    const at = toOut(mapped, im.at);
    if (at > total - 0.6) {
      console.warn(`${id}: a imagem ${k + 1} cai depois do fim do corte e foi ignorada.`);
      continue;
    }
    images.push({
      tipo,
      files,
      labels: im.labels || [],
      onde: im.onde || (tipo === 'logo' ? 'cima' : 'baixo'),
      at,
      dur: Math.min(dur, total - at),
    });
  }

  // 5) final "Seguir → Seguindo" nos últimos ~3 s (desliga com "final": false no corte ou "finalSeguir": false no config)
  const outro = clip.final !== false && cfg.finalSeguir !== false && total >= 8 ? {seconds: 3} : null;

  // 6) efeitos: impacto no quadro 0, whoosh só nas viradas, pop em cada imagem, clique no "Seguir".
  //    Menos de 15 efeitos a cada 35 s: se passar, os whooshes saem primeiro.
  const sfx = [];
  if (SFX.impacto) sfx.push({file: SFX.impacto, at: 0, volume: 0.5 * gain, prio: 0});
  if (SFX.pop) images.forEach((im) => sfx.push({file: SFX.pop, at: Math.max(0, im.at - 0.05), volume: 0.45 * gain, prio: 1}));
  if (outro && SFX.clique) sfx.push({file: SFX.clique, at: total - outro.seconds + 1.25, volume: 0.4 * gain, prio: 1});
  if (SFX.whoosh) mapped.filter((m) => m.turn).forEach((m) => sfx.push({file: SFX.whoosh, at: Math.max(0, m.outStart - 0.08), volume: 0.45 * gain, prio: 2}));
  const maxSfx = Math.max(3, Math.floor((total / 35) * 14));
  sfx.sort((a, b) => a.prio - b.prio || a.at - b.at);
  if (sfx.length > maxSfx) console.warn(`${id}: ${sfx.length} efeitos é demais para ${total.toFixed(0)} s; fiquei com ${maxSfx}.`);
  const sfxFinal = sfx.slice(0, maxSfx).map(({prio, ...s}) => s);

  const bottomStart = Math.min(clip.bottomStart ?? (8 + idx * 17) % Math.max(1, bottomTotal - 5), Math.max(0, bottomTotal - 5));
  const props = {
    totalSeconds: total,
    segments: mapped.map(({from, to, turn}) => ({from, to, turn: !!turn})),
    sourceFile: 'source.mp4',
    bottomFile: 'bottom.mp4',
    bottomStart,
    bottomDuration: bottomTotal - bottomStart,
    focus: clip.focus || {x: 50, y: 35},
    crop: clip.crop || null,
    sourceWidth: meta.width,
    sourceHeight: meta.height,
    pages: makePages(remapped),
    watermark: {logo: logoName, name: cfg.profileName},
    caption: {color: cfg.corPalavra || '#FFD400'},
    outro,
    sfx: sfxFinal,
    images,
  };
  const propsFile = path.join(work, `props-${id}.json`);
  fs.writeFileSync(propsFile, JSON.stringify(props));
  const out = path.resolve(outDir, `${id}.mp4`);
  console.log(`> Renderizando ${id} (${total.toFixed(1)} s, ${mapped.length} planos, ${images.length} imagens, ${sfxFinal.length} efeitos)`);
  // chama o CLI do Remotion direto pelo Node (sem shell): funciona com espaços no caminho, no Windows e fora dele
  const cli = path.join(ENGINE, 'node_modules', '@remotion', 'cli', 'remotion-cli.js');
  const r = spawnSync(
    process.execPath,
    [cli, 'render', 'src/index.js', 'SplitCut', out, `--props=${propsFile}`, `--public-dir=${path.resolve(work)}`, '--codec=h264', '--crf=20', '--log=error'],
    {cwd: ENGINE, stdio: 'inherit'},
  );
  results.push({id, arquivo: out, segundos: Number(total.toFixed(1)), ok: r.status === 0});
}
if (only.length && !results.length) fail(`Nenhum corte com id ${only.join(', ')} no cuts.json.`);
console.log(JSON.stringify(results, null, 2));
process.exit(results.every((r) => r.ok) ? 0 : 1);
