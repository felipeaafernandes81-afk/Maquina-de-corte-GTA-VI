#!/usr/bin/env node
// Confere o cuts.json ANTES do render: mostra como cada corte começa e termina (depois de encaixar nas palavras),
// a duração final sem as pausas e os problemas encontrados. Não muda nada.
// Uso: node conferir-cortes.mjs <pasta_de_trabalho>
// Sai com código 1 se houver erro (corte sobreposto, tempo inválido, nota abaixo de 6); avisos não bloqueiam.
import fs from 'node:fs';
import path from 'node:path';
import {FILLERS, mapTimeline, mmss, norm, sec, segmentsFor, snapClip} from './timeline.mjs';

const work = process.argv[2];
if (!work) {
  console.error('Uso: node conferir-cortes.mjs <pasta_de_trabalho>');
  process.exit(1);
}
const read = (f, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(work, f), 'utf8'));
  } catch {
    if (fallback !== undefined) return fallback;
    console.error(`Não consegui ler ${path.join(work, f)}.`);
    process.exit(1);
  }
};
const words = read('captions.json');
const silences = read('silences.json', []);
const {clips = []} = read('cuts.json');
const peaks = read('heatmap.json', {}).picos || [];

const text = (a, b) => words.slice(a, b).map((w) => w.text).join(' ');
const startsWithFiller = (t) => {
  const n = norm(t);
  return FILLERS.map(norm).find((f) => n === f || n.startsWith(f + ' '));
};
let errors = 0;
const spans = [];

for (const [i, c] of clips.entries()) {
  const id = c.id || `corte-${i + 1}`;
  const issues = [];
  const err = (m) => {
    issues.push(`  ERRO: ${m}`);
    errors++;
  };
  const warn = (m) => issues.push(`  aviso: ${m}`);
  if (!(c.end > c.start)) {
    err('"end" precisa ser maior que "start".');
    console.log(`\n${id}\n${issues.join('\n')}`);
    continue;
  }
  const s = snapClip(words, c.start, c.end);
  if (s.first < 0) {
    err('não há fala entre start e end.');
    console.log(`\n${id}\n${issues.join('\n')}`);
    continue;
  }
  const {total} = mapTimeline(segmentsFor(words, silences, s.start, s.end), 30);
  spans.push({id, a: s.start, b: s.end});

  const abertura = text(s.first, Math.min(s.first + 14, s.last + 1));
  const fecho = text(Math.max(s.first, s.last - 13), s.last + 1);
  const ultima = words[s.last].text;

  if (total < 20) warn(`curto (${total.toFixed(1)} s sem pausas); abaixo de 20 s costuma faltar payoff.`);
  if (total > 75) err(`longo demais (${total.toFixed(1)} s sem pausas); o limite é ~75 s.`);
  else if (total > 60) warn(`longo (${total.toFixed(1)} s sem pausas); só vale se o assunto for excelente.`);
  const f = startsWithFiller(abertura);
  if (f) warn(`começa com aquecimento ("${f}…"); avance o start até a frase do gancho.`);
  if (!/[.!?…]["”')\]]*$/.test(ultima)) warn(`termina sem fechar a frase ("…${ultima}"); estenda o end até o fim do payoff.`);
  if (/^(né|ne|entendeu|sabe|tá|ta)\??$/i.test(norm(ultima))) warn('termina num "né?"/"sabe?" solto; recue o end para a frase anterior.');
  if (c.hook) {
    const hw = norm(c.hook).split(' ').filter((x) => x.length > 2);
    const ow = new Set(norm(text(s.first, Math.min(s.first + hw.length + 6, s.last + 1))).split(' '));
    const hit = hw.length ? hw.filter((x) => ow.has(x)).length / hw.length : 1;
    if (hit < 0.6) warn(`a frase de gancho não está no começo do corte (só ${(hit * 100).toFixed(0)}% das palavras batem). O corte precisa abrir NELA.`);
  } else warn('sem "hook" (a frase de gancho) no cuts.json.');
  if (typeof c.nota === 'number' && c.nota < 6) err(`nota ${c.nota}: abaixo de 6 é descarte.`);
  if (peaks.length) {
    const k = peaks.findIndex((p) => p.fim >= s.start && p.inicio <= s.end);
    if (k >= 0) issues.push(`  + pega o PICO ${k + 1} do "mais reproduzido".`);
  }

  console.log(`\n${id}  [${mmss(s.start)} → ${mmss(s.end)}]  ${total.toFixed(1)} s sem pausas  nota ${c.nota ?? '?'}`);
  console.log(`  abre:   ${abertura}${s.last - s.first > 13 ? ' …' : ''}`);
  console.log(`  fecha:  … ${fecho}`);
  if (issues.length) console.log(issues.join('\n'));
}

// sobreposição e repetição entre cortes
spans.sort((x, y) => x.a - y.a);
for (let k = 1; k < spans.length; k++) {
  if (spans[k].a < spans[k - 1].b) {
    console.log(`\nERRO: ${spans[k - 1].id} e ${spans[k].id} se sobrepõem.`);
    errors++;
  }
}
const seen = new Map();
for (const c of clips) {
  const a = c.assunto && norm(c.assunto);
  if (!a) continue;
  if (seen.has(a)) console.log(`\naviso: ${seen.get(a)} e ${c.id} têm o mesmo assunto ("${c.assunto}").`);
  seen.set(a, c.id);
}
const ids = clips.map((c) => c.id);
if (new Set(ids).size !== ids.length) {
  console.log('\nERRO: há ids repetidos (os arquivos se sobrescreveriam).');
  errors++;
}
console.log(errors ? `\n${errors} erro(s). Corrija o cuts.json antes de renderizar.` : '\nSem erros. Pode renderizar.');
process.exit(errors ? 1 : 0);
