// Acha e roda programas de linha de comando sem shell, inclusive no Windows (onde os instalados pelo npm
// são atalhos .cmd que não rodam sem shell). Sem shell, textos com aspas e quebras de linha passam intactos.
import {spawn, spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const WIN = process.platform === 'win32';
const cache = new Map();

function npmRoot() {
  const r = spawnSync(WIN ? 'npm.cmd' : 'npm', ['root', '-g'], {encoding: 'utf8', shell: WIN});
  return r.status === 0 ? r.stdout.trim() : null;
}

// name: comando; pkg: pacote npm que o instala (para achar o .js no Windows)
export function resolveBin(name, pkg) {
  const key = `${name}|${pkg}`;
  if (cache.has(key)) return cache.get(key);
  let res = null;
  const w = spawnSync(WIN ? 'where' : 'which', [name], {encoding: 'utf8'});
  const found = w.status === 0 ? w.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean) : [];
  const exe = found.find((f) => !WIN || /\.exe$/i.test(f));
  if (exe) res = {cmd: exe, pre: []};
  else if (pkg) {
    const root = npmRoot();
    const pj = root && path.join(root, pkg, 'package.json');
    if (pj && fs.existsSync(pj)) {
      const meta = JSON.parse(fs.readFileSync(pj, 'utf8'));
      const rel = typeof meta.bin === 'string' ? meta.bin : meta.bin?.[name] ?? Object.values(meta.bin || {})[0];
      if (rel) res = {cmd: process.execPath, pre: [path.join(root, pkg, rel)]};
    }
  }
  cache.set(key, res);
  return res;
}

export function runBin(name, pkg, args, opts = {}) {
  const b = resolveBin(name, pkg);
  if (!b) return {ok: false, out: '', err: `"${name}" não encontrado no PATH.`};
  const r = spawnSync(b.cmd, [...b.pre, ...args], {encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, ...opts});
  return {ok: r.status === 0, out: r.stdout || '', err: (r.stderr || r.error?.message || '').trim(), status: r.status};
}

// Versão assíncrona (não trava o Node enquanto roda: a gravação da live continua fluindo).
export function runAsync(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    let out = '';
    let err = '';
    let p;
    try {
      p = spawn(cmd, args, {...opts, stdio: [opts.input != null ? 'pipe' : 'ignore', 'pipe', 'pipe']});
    } catch (e) {
      resolve({ok: false, out: '', err: e.message});
      return;
    }
    const cap = (s, d) => (s.length > 2e6 ? s.slice(-1e6) : s) + d;
    p.stdout.on('data', (d) => (out = cap(out, d)));
    p.stderr.on('data', (d) => (err = cap(err, d)));
    if (opts.input != null) p.stdin.end(opts.input);
    const timer = opts.timeoutMs ? setTimeout(() => p.kill(), opts.timeoutMs) : null;
    p.on('error', (e) => {
      if (timer) clearTimeout(timer);
      resolve({ok: false, out, err: e.message});
    });
    p.on('close', (code) => {
      if (timer) clearTimeout(timer);
      resolve({ok: code === 0, out, err: err.trim(), status: code});
    });
  });
}
export function runBinAsync(name, pkg, args, opts = {}) {
  const b = resolveBin(name, pkg);
  if (!b) return Promise.resolve({ok: false, out: '', err: `"${name}" não encontrado no PATH.`});
  return runAsync(b.cmd, [...b.pre, ...args], opts);
}
