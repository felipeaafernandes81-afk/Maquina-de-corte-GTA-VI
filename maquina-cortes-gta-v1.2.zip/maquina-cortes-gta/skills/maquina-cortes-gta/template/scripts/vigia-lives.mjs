#!/usr/bin/env node
// MODO AUTOMÁTICO: vigia canais, grava as lives em blocos, escolhe os cortes com o Claude Code, renderiza e posta
// no YouTube, TikTok e Instagram pelo Postiz. Roda no seu computador enquanto estiver aberto.
//
//   node vigia-lives.mjs                       vigia os canais do automatico.json (deixe rodando)
//   node vigia-lives.mjs --exemplo             cria ~/.maquina-cortes-gta/automatico.json de exemplo
//   node vigia-lives.mjs --uma-vez video.mp4   processa um arquivo como se fosse um bloco de live (teste)
//   ... --sem-postar                           faz tudo, menos postar (teste)
//
// Pausar: crie o arquivo ~/.maquina-cortes-gta/PAUSAR (ou "pausado": true no automatico.json). Apague para voltar.
// Registro de tudo que acontece: ~/.maquina-cortes-gta/automatico.log
import {spawn} from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {resolveBin, runAsync, runBinAsync} from './bin.mjs';
import {postClip} from './postar.mjs';

const HOME = path.join(os.homedir(), '.maquina-cortes-gta');
const ENGINE = path.join(HOME, 'engine');
const S = path.dirname(fileURLToPath(import.meta.url));
const CFG = path.join(HOME, 'automatico.json');
const STATE = path.join(HOME, 'automatico-estado.json');
const LOG = path.join(HOME, 'automatico.log');
const PAUSE = path.join(HOME, 'PAUSAR');
const args = process.argv.slice(2);
const DRY = args.includes('--sem-postar');

const EXEMPLO = {
  canais: ['https://www.youtube.com/@CANAL_DO_STREAMER', 'https://www.twitch.tv/CANAL_DO_STREAMER'],
  redes: {youtube: 'ID_DO_POSTIZ', tiktok: 'ID_DO_POSTIZ', instagram: 'ID_DO_POSTIZ'},
  ajustes: {youtube: {}, tiktok: {}, instagram: {}},
  hashtags: ['#gta6', '#gta', '#shorts'],
  creditar: true,
  idioma: 'pt',
  bottom: 'https://www.youtube.com/watch?v=rz1B4B2yBZY',
  pasta: path.join(HOME, 'auto'),
  blocoSegundos: 900,
  checarACadaSegundos: 120,
  notaMinima: 7,
  maxCortesPorBloco: 2,
  maxPostsPorDia: 6,
  minutosEntrePosts: 45,
  apagarBrutos: true,
  claudeArgs: ['--allowedTools', 'Read,Write,Edit,Bash(node:*)'],
  pausado: false,
};

const log = (...m) => {
  const line = `[${new Date().toLocaleString('pt-BR')}] ${m.join(' ')}`;
  console.log(line);
  try {
    fs.appendFileSync(LOG, line + '\n');
  } catch {
    /* sem log em disco */
  }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const readJson = (f, fb) => {
  try {
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    return fb;
  }
};
const loadCfg = () => ({...EXEMPLO, ...readJson(CFG, {})});
const state = readJson(STATE, {gravacoes: {}, postados: [], agenda: [], recentes: []});
const save = () => fs.writeFileSync(STATE, JSON.stringify(state, null, 2));
const slug = (s) =>
  String(s || 'canal')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 40) || 'canal';
const paused = (cfg) => cfg.pausado || fs.existsSync(PAUSE);

// ---------- config de exemplo ----------
if (args.includes('--exemplo')) {
  fs.mkdirSync(HOME, {recursive: true});
  if (fs.existsSync(CFG)) console.log(`Já existe: ${CFG} (não mexi).`);
  else {
    fs.writeFileSync(CFG, JSON.stringify(EXEMPLO, null, 2));
    console.log(`Criado: ${CFG}. Preencha "canais" e "redes".`);
  }
  process.exit(0);
}

// ---------- live? ----------
const liveUrl = (u) => (/youtube\.com\/(@|channel\/|c\/)/.test(u) && !/\/live\/?$/.test(u) ? u.replace(/\/$/, '') + '/live' : u);
async function liveInfo(url) {
  const r = await runAsync(resolveBin('yt-dlp')?.cmd || 'yt-dlp', ['--no-warnings', '--skip-download', '--playlist-items', '1', '--print', '%(live_status)s\t%(id)s\t%(channel,uploader)s\t%(title)s', liveUrl(url)], {timeoutMs: 90e3});
  if (!r.ok) return null;
  const [status, id, canal, titulo] = r.out.trim().split('\n').pop().split('\t');
  return status === 'is_live' ? {id, canal, titulo, url: liveUrl(url)} : null;
}

// ---------- gravação em blocos ----------
const recorders = new Map(); // url -> {dir, info, done}
function startRecording(url, info, cfg) {
  const dir = path.join(cfg.pasta, slug(info.canal), `${new Date().toISOString().slice(0, 10)}-${slug(info.id)}`);
  fs.mkdirSync(dir, {recursive: true});
  const part = `p${Date.now()}`;
  const rec = {dir, info, done: false, part};
  state.gravacoes[dir] ??= {processados: [], info, inicio: Date.now()};
  save();
  const yt = spawn(resolveBin('yt-dlp')?.cmd || 'yt-dlp', ['--no-warnings', '--no-part', '-f', 'best[height<=1080]/best', '-o', '-', info.url], {stdio: ['ignore', 'pipe', 'ignore']});
  const ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', 'pipe:0', '-map', '0:v:0?', '-map', '0:a:0?', '-c', 'copy', '-f', 'segment', '-segment_time', String(cfg.blocoSegundos), '-reset_timestamps', '1', path.join(dir, `${part}-%03d.ts`)], {stdio: ['pipe', 'ignore', 'ignore']});
  yt.stdout.pipe(ff.stdin);
  yt.stdout.on('error', () => {});
  ff.stdin.on('error', () => {});
  yt.on('close', () => ff.stdin.end());
  yt.on('error', (e) => log(`yt-dlp falhou: ${e.message}`));
  ff.on('close', () => {
    rec.done = true;
    log(`Gravação parou: ${info.canal} (a live acabou ou caiu; se ainda estiver no ar, volto a gravar na próxima checagem).`);
  });
  recorders.set(url, rec);
  log(`AO VIVO: ${info.canal} — "${info.titulo}". Gravando em blocos de ${cfg.blocoSegundos >= 60 ? Math.round(cfg.blocoSegundos / 60) + " min" : cfg.blocoSegundos + " s"}.`);
}

// blocos prontos = todos menos o último de cada parte (que ainda está sendo gravado), a não ser que a gravação acabou
function readyBlocks() {
  const out = [];
  for (const [dir, g] of Object.entries(state.gravacoes)) {
    if (!fs.existsSync(dir)) continue;
    const live = [...recorders.values()].find((r) => r.dir === dir && !r.done);
    const files = fs.readdirSync(dir).filter((f) => /^p\d+-\d{3}\.ts$/.test(f)).sort();
    for (const f of files) {
      if (g.processados.includes(f)) continue;
      const growing = live && f.startsWith(live.part) && f === files.filter((x) => x.startsWith(live.part)).pop();
      if (!growing) out.push({dir, file: f, info: g.info});
    }
  }
  return out;
}

// ---------- agenda de posts ----------
function nextSlot(cfg) {
  const now = Date.now();
  state.agenda = state.agenda.filter((t) => t > now - 26 * 3600e3);
  const last = state.agenda.length ? Math.max(...state.agenda) : 0;
  const t = Math.max(now + 2 * 60e3, last + cfg.minutosEntrePosts * 60e3);
  const inDay = state.agenda.filter((x) => x > t - 24 * 3600e3).length;
  if (inDay >= cfg.maxPostsPorDia || t > now + 24 * 3600e3) return null;
  return t;
}

// ---------- vídeo de baixo (baixado uma vez) ----------
async function bottomFile(cfg) {
  if (cfg.bottom && fs.existsSync(cfg.bottom)) return cfg.bottom;
  const cached = path.join(HOME, 'cache', 'bottom.mp4');
  if (fs.existsSync(cached)) return cached;
  fs.mkdirSync(path.dirname(cached), {recursive: true});
  log('Baixando o vídeo da metade de baixo (uma vez só)…');
  const r = await runAsync(resolveBin('yt-dlp')?.cmd || 'yt-dlp', ['-S', 'res:720', '-f', 'bv*+ba/b', '--merge-output-format', 'mp4', '--no-playlist', '-o', cached, cfg.bottom]);
  return r.ok && fs.existsSync(cached) ? cached : null;
}

// ---------- um bloco: transcrever → Claude escolhe → conferir → render → postar ----------
async function processBlock({dir, file, info}, cfg) {
  const src = path.join(dir, file);
  const base = path.join(dir, file.replace(/\.ts$|\.mp4$/i, ''));
  const work = path.join(base, 'work');
  fs.mkdirSync(work, {recursive: true});
  const tag = `${info.canal} ${file}`;

  let r = await runAsync('ffmpeg', ['-y', '-v', 'error', '-i', src, '-c', 'copy', '-movflags', '+faststart', path.join(work, 'source.mp4')]);
  if (!r.ok) r = await runAsync('ffmpeg', ['-y', '-v', 'error', '-i', src, '-c:v', 'libx264', '-preset', 'veryfast', '-c:a', 'aac', path.join(work, 'source.mp4')]);
  if (!r.ok) return log(`${tag}: não consegui preparar o vídeo (${r.err.slice(0, 150)}).`);
  const bottom = await bottomFile(cfg);
  if (!bottom) return log(`${tag}: sem vídeo da metade de baixo (confira "bottom" no automatico.json).`);
  fs.copyFileSync(bottom, path.join(work, 'bottom.mp4'));
  await runAsync('ffmpeg', ['-y', '-v', 'error', '-ss', '20', '-i', path.join(work, 'source.mp4'), '-frames:v', '1', path.join(work, 'frame.jpg')]);

  log(`${tag}: transcrevendo…`);
  r = await runAsync(process.execPath, [path.join(S, 'transcribe.mjs'), path.join(work, 'source.mp4'), work, cfg.idioma], {cwd: ENGINE});
  if (!r.ok) return log(`${tag}: transcrição falhou (${r.err.slice(-200)}).`);
  const meta = readJson(path.join(work, 'meta.json'), {});
  if ((meta.duration || 0) < 120) return log(`${tag}: bloco curto demais (${Math.round(meta.duration || 0)} s), pulei.`);

  const recentes = state.recentes.filter((x) => x.t > Date.now() - 48 * 3600e3).map((x) => x.assunto);
  const prompt = [
    'Modo automático da máquina-cortes-gta. NÃO faça perguntas: ninguém vai responder.',
    `Pasta de trabalho: ${work} (já tem captions.json, silences.json, meta.json, source.mp4 e frame.jpg).`,
    `Live: "${info.titulo}" de ${info.canal}. Bloco de ${Math.round(meta.duration / 60)} min.`,
    `1. Leia o guia ${path.join(ENGINE, 'references', 'ganchos.md')}.`,
    `2. Leia a transcrição: node "${path.join(S, 'transcript-text.mjs')}" "${work}" (use --de/--ate/--palavras para acertar os tempos).`,
    `3. Olhe ${path.join(work, 'frame.jpg')} para acertar "focus" (ou "crop", se for live com várias câmeras).`,
    `4. Escolha de 0 a ${cfg.maxCortesPorBloco} cortes com nota >= ${cfg.notaMinima}, de 20 a 60 s, de assuntos diferentes, começando na frase do gancho e terminando no payoff. Só cortes sobre GTA.`,
    recentes.length ? `   Não repita estes assuntos, já postados nas últimas 48 h: ${recentes.join('; ')}.` : '',
    '   Se nada passar da nota, grave {"clips": []}. Não force corte ruim.',
    `5. Grave ${path.join(work, 'cuts.json')}: {"clips":[{"id":"01-assunto","start":0,"end":0,"focus":{"x":50,"y":35},"assunto":"","hook":"","nota":0,"titulo":"até 60 caracteres, sem entregar o payoff","descricao":"1 frase","turns":[]}]}. Sem "images".`,
    `6. Rode node "${path.join(S, 'conferir-cortes.mjs')}" "${work}" e corrija até sair "Sem erros"; trate os avisos.`,
    '7. Não renderize e não poste. Responda só "ok".',
  ]
    .filter(Boolean)
    .join('\n');
  log(`${tag}: escolhendo os cortes (Claude Code)…`);
  r = await runBinAsync('claude', '@anthropic-ai/claude-code', ['-p', ...cfg.claudeArgs], {input: prompt, cwd: base, timeoutMs: 25 * 60e3});
  if (!r.ok) return log(`${tag}: o Claude Code falhou (${(r.err || r.out).slice(-200)}).`);

  const cuts = readJson(path.join(work, 'cuts.json'), {clips: []});
  cuts.clips = (cuts.clips || []).filter((c) => (c.nota ?? 0) >= cfg.notaMinima && !state.postados.includes(`${info.id}:${Math.round(c.start)}`));
  if (!cuts.clips.length) return log(`${tag}: nenhum corte bom o bastante neste bloco.`);
  fs.writeFileSync(path.join(work, 'cuts.json'), JSON.stringify(cuts, null, 2));
  r = await runAsync(process.execPath, [path.join(S, 'conferir-cortes.mjs'), work]);
  if (!r.ok) return log(`${tag}: o conferidor achou erro; não postei.\n${r.out.slice(-500)}`);

  log(`${tag}: renderizando ${cuts.clips.length} corte(s)…`);
  const outDir = path.join(base, 'cortes');
  r = await runAsync(process.execPath, [path.join(S, 'build.mjs'), work, outDir], {cwd: ENGINE});
  let results = [];
  try {
    results = JSON.parse(r.out.slice(r.out.lastIndexOf('\n[')));
  } catch {
    results = cuts.clips.map((c) => ({id: c.id, arquivo: path.join(outDir, `${c.id}.mp4`), ok: fs.existsSync(path.join(outDir, `${c.id}.mp4`))}));
  }

  for (const c of cuts.clips) {
    const res = results.find((x) => x.id === c.id || x.id === String(c.id).replace(/[^\p{L}\p{N}_-]+/gu, '-'));
    if (!res?.ok) {
      log(`${tag}: o render de ${c.id} falhou.`);
      continue;
    }
    const key = `${info.id}:${Math.round(c.start)}`;
    state.recentes.push({assunto: c.assunto, t: Date.now()});
    if (DRY) {
      log(`${tag}: pronto (sem postar): ${res.arquivo} — "${c.titulo}" (nota ${c.nota})`);
      continue;
    }
    const when = nextSlot(cfg);
    if (!when) {
      log(`${tag}: limite de ${cfg.maxPostsPorDia} posts por dia atingido; ${c.id} ficou só no disco (${res.arquivo}).`);
      continue;
    }
    const out = await postClip({video: res.arquivo, titulo: c.titulo || c.hook, descricao: c.descricao || '', credito: cfg.creditar ? info.canal : '', quando: new Date(when), cfg, log});
    if (out.some((o) => o.ok)) {
      state.agenda.push(when);
      state.postados.push(key);
    }
    save();
  }
  save();
}

// ---------- laço principal ----------
async function main() {
  fs.mkdirSync(HOME, {recursive: true});
  for (const [bin, how] of [
    ['yt-dlp', 'instale o yt-dlp'],
    ['ffmpeg', 'instale o FFmpeg'],
    ['claude', 'instale o Claude Code'],
    ...(DRY ? [] : [['postiz', 'npm install -g postiz']]),
  ]) {
    if (!resolveBin(bin, bin === 'claude' ? '@anthropic-ai/claude-code' : bin === 'postiz' ? 'postiz' : undefined)) {
      console.error(`Falta "${bin}": ${how}.`);
      process.exit(1);
    }
  }

  const once = args.indexOf('--uma-vez');
  if (once >= 0) {
    const f = path.resolve(args[once + 1] || '');
    if (!fs.existsSync(f)) {
      console.error('Uso: node vigia-lives.mjs --uma-vez video.mp4 [--sem-postar]');
      process.exit(1);
    }
    const cfg = loadCfg();
    const dir = path.join(cfg.pasta, 'teste', slug(path.basename(f)));
    fs.mkdirSync(dir, {recursive: true});
    const name = 'p0-000' + path.extname(f).toLowerCase();
    fs.copyFileSync(f, path.join(dir, name));
    await processBlock({dir, file: name, info: {id: slug(path.basename(f)), canal: 'teste', titulo: path.basename(f)}}, cfg);
    save();
    return;
  }

  log(`Vigia ligado${DRY ? ' (sem postar)' : ''}. Para pausar, crie ${PAUSE}.`);
  let lastCheck = 0;
  let wasPaused = false;
  for (;;) {
    const cfg = loadCfg(); // relido a cada volta: dá para mudar o automatico.json sem reiniciar
    if (paused(cfg)) {
      if (!wasPaused) log('Pausado. Gravações em andamento continuam; nada novo é processado nem postado.');
      wasPaused = true;
      await sleep(30e3);
      continue;
    }
    if (wasPaused) log('Voltou a rodar.');
    wasPaused = false;

    if (Date.now() - lastCheck > cfg.checarACadaSegundos * 1000) {
      lastCheck = Date.now();
      for (const url of cfg.canais || []) {
        const rec = recorders.get(url);
        if (rec && !rec.done) continue;
        const info = await liveInfo(url);
        if (info) startRecording(url, info, cfg);
      }
    }

    const ready = readyBlocks();
    if (ready.length > 3) log(`Atenção: ${ready.length} blocos na fila (o processamento está mais lento que a live).`);
    const next = ready[0];
    if (!next) {
      await sleep(15e3);
      continue;
    }
    try {
      await processBlock(next, cfg);
    } catch (e) {
      log(`Erro no bloco ${next.file}: ${e.message}`);
    }
    state.gravacoes[next.dir].processados.push(next.file);
    if (cfg.apagarBrutos) {
      fs.rmSync(path.join(next.dir, next.file), {force: true});
      fs.rmSync(path.join(next.dir, next.file.replace(/\.ts$/, ''), 'work'), {recursive: true, force: true});
    }
    save();
  }
}

main().catch((e) => {
  log(`Vigia parou: ${e.stack || e.message}`);
  process.exit(1);
});
