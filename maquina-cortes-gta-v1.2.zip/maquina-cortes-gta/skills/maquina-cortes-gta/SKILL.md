---
name: maquina-cortes-gta
description: Transforma um vídeo de streamer ou podcast (link ou arquivo) em vários cortes verticais de Shorts sobre GTA 6, cada um com um assunto e um gancho diferente, no estilo metade streamer e metade vídeo, com legenda palavra por palavra, pausas cortadas, zoom nos cortes e a marca d'água do seu perfil (logo + nome). Também tem um modo automático que vigia lives, corta e posta sozinho no YouTube, TikTok e Instagram. Use com /maquina-cortes-gta ou quando o usuário pedir cortes de GTA, "cortar esse vídeo", "máquina de cortes", "modo automático" ou "postar as lives sozinho".
---

# máquina-cortes-gta

Você recebe um vídeo longo e entrega **vários cortes prontos** em 9:16, cada um sobre um assunto diferente, com o gancho escolhido por você a partir da transcrição. Edição feita em Remotion; transcrição local com whisper.cpp. Tudo roda no computador do usuário.

Escreva pouco no chat: nunca despeje a transcrição nem JSON inteiro; mostre só o que o usuário precisa decidir ou receber.

`<skill>` = a pasta onde este SKILL.md está. `~/.maquina-cortes-gta` = pasta de dados do usuário (motor, whisper, nome do perfil e logo). `<motor>` = `~/.maquina-cortes-gta/engine/scripts`.

## 0. Conferir a instalação

```bash
node "<skill>/scripts/setup.mjs" --check
```

- `engine: false`, `whisperModel: false` ou `motorAtualizado: false`: rode `node "<skill>/scripts/setup.mjs"`. Na 1ª vez instala o Remotion e o whisper.cpp (alguns minutos, ~1 GB; avise antes). Com `motorAtualizado: false` só copia a versão nova dos scripts e componentes (rápido).
- `ffmpeg: false`: peça para o usuário instalar o FFmpeg (o script mostra o comando do sistema dele) e pare.
- `ytdlp: false`: só aceite arquivo de vídeo (não link) e diga como instalar o yt-dlp.
- **Opcionais** (avise uma vez, em até 3 linhas, com as opções; não pare o trabalho):
  - `efeitosGerados: 0`: "Sem efeitos sonoros. Opções: (a) gerar com a ElevenLabs (`ELEVENLABS_API_KEY`, gasta créditos seus, 3 efeitos curtos); (b) colocar sons seus em `~/.maquina-cortes-gta/sfx/` (`impacto`, `whoosh`, `pop` e, se quiser, `clique`; mp3 ou wav); (c) seguir sem efeitos."
  - `googleImagens: false`: "Sem busca de imagens no Google. Opções: (a) configurar `GOOGLE_API_KEY` e `GOOGLE_CSE_ID`; (b) mandar as imagens como arquivo; (c) seguir sem imagens." Não tente raspar a busca do Google por navegador (dá CAPTCHA). Arte oficial baixada de um site da Rockstar pode entrar como `file`.
  - Depois da escolha do usuário, não pergunte de novo na mesma conversa.

## 1. Perfil (só na primeira vez)

Se `perfilConfigurado` for `false`, peça **numa única mensagem**:

1. o **nome do perfil** como deve aparecer na marca d'água e no final "Seguir" (ex.: `SEU CANAL`, sem @);
2. a **logo** (o usuário anexa a imagem; PNG ou JPG, de preferência quadrada).

Ache o caminho do arquivo anexado e rode:

```bash
node "<skill>/scripts/setup.mjs" --profile "NOME DO PERFIL" --logo "CAMINHO/DA/LOGO.png"
```

Depois disso **não pergunte de novo**, a menos que o usuário peça para trocar.

## 2. Pedir o vídeo

Peça o **vídeo de origem** (link ou arquivo) e, na mesma mensagem, ofereça o **vídeo da metade de baixo** (gameplay, trailer ou B-roll). Sem ele, use o trailer oficial da Rockstar: `https://www.youtube.com/watch?v=rz1B4B2yBZY` (se o link falhar, peça outro).

## 3. Preparar a pasta de trabalho

Use `./cortes/<slug>/work/` na pasta atual (`<slug>` = o assunto do vídeo, em minúsculas e com hífen).

```bash
yt-dlp -S "res:1080" -f "bv*+ba/b" --merge-output-format mp4 --no-playlist -o "work/source.%(ext)s" "LINK_DA_ORIGEM"
yt-dlp -S "res:720"  -f "bv*+ba/b" --merge-output-format mp4 --no-playlist -o "work/bottom.%(ext)s" "LINK_DA_METADE_DE_BAIXO"
```

Se for arquivo, copie para `work/source.mp4` (e `work/bottom.mp4`); se não for mp4, converta com `ffmpeg -i ARQ -c:v libx264 -c:a aac work/source.mp4`. HTTP 429: espere e tente de novo; se persistir, peça o arquivo. **Restrição de idade** ("Sign in to confirm your age"): peça o arquivo; **não use os cookies do navegador do usuário sem ele pedir**.

Se a origem for um **link do YouTube**, leia também o gráfico "Mais reproduzidos" (sem navegador, pelo yt-dlp):

```bash
node <motor>/mais-reproduzido.mjs "LINK_DA_ORIGEM" work
```

Grava `work/heatmap.json` e lista os picos. Sem gráfico (vídeo novo ou com poucas visualizações), siga só pela transcrição.

## 4. Transcrever

```bash
node <motor>/transcribe.mjs work/source.mp4 work pt
```

(Troque `pt` pelo idioma do vídeo. Um 4º argumento opcional limita aos primeiros N segundos, para testar rápido.) Gera `captions.json`, `silences.json` e `meta.json`. Para **ler**:

```bash
node <motor>/transcript-text.mjs work                                  # frases "[mm:ss.s] ..."; picos marcados [PICO n]
node <motor>/transcript-text.mjs work --de 5:10 --ate 6:00             # só um trecho
node <motor>/transcript-text.mjs work --de 312 --ate 320 --palavras    # cada palavra com o segundo exato
```

Leia em blocos. Use `--palavras` para acertar o segundo exato do início do gancho e do fim do payoff.

## 5. Escolher os cortes (você decide sozinho)

O usuário **não escolhe** os trechos. Siga `references/ganchos.md`. Resumo:

1. **Mapa de assuntos:** divida a conversa em blocos por tema, com o minuto de cada um.
2. **Candidatos:** em cada bloco, ache as frases que abrem uma curiosidade, trazem um fato específico (número, nome, comparação com GTA V), um conflito ou uma opinião forte. Os **picos do "mais reproduzido"** são candidatos fortes: cruze com a transcrição.
3. **Escolha de 3 a 5 cortes** (2 se o vídeo tiver menos de 5 min), de **20 a 60 s sem pausas**, cada um de um **assunto diferente** e com um **gancho diferente**. Sem sobreposição.
4. **Comece na frase do gancho** (sem "então, galera") e **termine no payoff** (frase que responde o gancho).
5. **Nota de 0 a 10** a cada gancho; **descarte** abaixo de 6. Se faltar corte bom, entregue menos e diga por quê.
6. **Enquadramento:** extraia um quadro (`ffmpeg -ss 5 -i work/source.mp4 -frames:v 1 work/frame.jpg`), olhe e ajuste `focus` (`x`, `y` de 0 a 100) ou `crop` (veja abaixo).
7. Grave `work/cuts.json`:

```json
{
  "clips": [
    {
      "id": "01-tamanho-do-mapa",
      "start": 312.4,
      "end": 358.0,
      "focus": {"x": 50, "y": 35},
      "assunto": "tamanho do mapa",
      "hook": "O mapa do GTA 6 é a soma de três mapas.",
      "nota": 8,
      "titulo": "O mapa do GTA 6 é GIGANTE",
      "turns": [331.0, 344.2],
      "images": [{"tipo": "comparar", "queries": ["mapa GTA 5", "mapa GTA 6 Leonida"], "labels": ["GTA 5", "GTA 6"], "at": 318.0}]
    }
  ]
}
```

`id` = número + assunto. `start` e `end` não precisam ser exatos: o build encaixa o início ~0,15 s antes da 1ª palavra e o fim ~0,25 s depois da última. Opcionais: `bottomStart` (ponto de partida do vídeo de baixo), `ritmo`, `cutEvery`, `final: false`.

8. **Confira antes de renderizar** (obrigatório):

```bash
node <motor>/conferir-cortes.mjs work
```

Mostra como cada corte abre e fecha, a duração final e os problemas (aquecimento no início, frase sem fechar, gancho fora do começo, sobreposição, nota baixa). Corrija o `cuts.json` até sair "Sem erros"; trate os avisos.

**Live com várias câmeras ou tela do jogo ocupando o quadro:** o `focus` sozinho não acha o streamer. Adicione `"crop": {"x": 1092, "y": 118, "w": 146, "h": 130}` em **pixels do vídeo de origem**, em volta da câmera de quem fala (proporção ~1,125:1). Câmera pequena ampliada fica borrada; avise o usuário.

## Ritmo, imagens e efeitos

**Jump cuts (padrão):** o build quebra planos longos a cada ~2,8 s, sempre no começo de uma palavra (não remove conteúdo). Cada quebra é um **corte seco: só o zoom alterna 100% ↔ 107%**, sem flash e sem swoosh. `"ritmo": "normal"` só tira as pausas; `"cutEvery"` muda o intervalo. (`"ritmo": "rapido"`, com swoosh em todo corte, existe por compatibilidade; fica repetitivo, não use.)

**Viradas de seção (`turns`):** segundos do vídeo de origem onde muda o assunto, entra um popup importante ou o streamer cita um console. Só nelas entram **flash, punch-in e swoosh**. Use de 2 a 5 por corte.

**Pausas:** entre frases, pausa acima de 0,3 s fica com 0,2 s. Dentro da frase, só sai hesitação acima de 0,8 s. Ajustável no `config.json` (`pausaMinima`, `pausaFica`, `pausaLongaNaFrase`).

**Popups (`images`):** 1 a 3 por corte, com `at` em **segundos do vídeo de origem**, sempre com imagem real (nunca só texto). Tipos:

| `tipo` | Quando usar | Campos |
|---|---|---|
| `foto` (padrão) | capa/arte do jogo, mapa, personagem, console | `file` ou `query`, `dur` (2,2 s) |
| `logo` | 1ª menção do jogo ou "Rockstar": logo **com fundo transparente** vindo em direção à tela, sobre o streamer | `file` (PNG transparente), `dur` |
| `comparar` | comparação lado a lado ("GTA 5 \| GTA 6") | `files` ou `queries` (2), `labels`, `dur` (3 s) |

`onde: "cima" | "baixo"` muda a metade (padrão: `logo` em cima, o resto embaixo). `query` busca no Google pela API oficial (precisa de `GOOGLE_API_KEY` e `GOOGLE_CSE_ID`); sem elas, a imagem é pulada com aviso. Prefira material oficial. Mapa feito por fã leva a observação "não oficial" no título; **não use mapa vazado**.

**Efeitos sonoros:** em `~/.maquina-cortes-gta/sfx/`. Impacto no quadro 0, whoosh nas viradas, pop em cada popup, clique no "Seguir" (usa `clique` ou, sem ele, `pop`). O build limita a menos de 15 efeitos por 35 s (sobrando, tira whooshes). Volume em `sfxGain` no `config.json` (padrão 0,6). Se `efeitosGerados` for 0, **pergunte uma vez** se o usuário quer gerar e, só com o OK:

```bash
node "<skill>/scripts/gerar-paleta-sfx.mjs"
```

Usa a skill `sound-effects` (glebis, MIT) que vem junto e a variável `ELEVENLABS_API_KEY`. Nunca peça nem escreva a chave no chat.

**Final "Seguir → Seguindo":** automático nos últimos 3 s de cortes com 8 s ou mais: pílula com a logo e o nome, um cursor clica em "Seguir" e vira "Seguindo ✓". Desliga com `"final": false` no corte ou `"finalSeguir": false` no `config.json`.

## 6. Renderizar

```bash
node <motor>/build.mjs work .
node <motor>/build.mjs work . 02-pre-download     # só um corte (ex.: refazer o que falhou)
```

Gera `./01-....mp4` etc. (1080×1920, 30 fps, H.264). O **primeiro render** pode baixar o Chrome headless do Remotion. Se um corte falhar, mostre o erro e renderize os outros.

## 7. Entregar

Responda curto: a lista dos arquivos e uma tabela com **assunto, gancho (a frase), duração, nota e título sugerido** de cada corte. Nada além disso.

## Modo automático (lives → cortes → posts)

Quando o usuário pedir para **ligar o modo automático**, vigiar lives ou postar sozinho, faça a configuração abaixo (uma vez). Depois disso o vigia roda sem o Claude na conversa: detecta a live, grava em blocos de 15 min, chama o Claude Code em modo `-p` para escolher os cortes de cada bloco, confere, renderiza e posta no YouTube (Shorts), TikTok e Instagram (Reels) pelo **Postiz**.

1. **Pré-requisitos:** `setup.mjs --check` precisa mostrar `perfilConfigurado: true` (seção 1). Se `postiz: false`, rode `npm install -g postiz`.
2. **Postiz:** o usuário cria a conta em postiz.com (ou instala o Postiz próprio), conecta lá o YouTube, o TikTok e o Instagram (Instagram precisa ser conta profissional) e roda `postiz auth:login` (termina no navegador). Você não faz o login por ele.
3. **Config:** `node <motor>/vigia-lives.mjs --exemplo` cria `~/.maquina-cortes-gta/automatico.json`. Pergunte **os canais a vigiar** (links do YouTube, Twitch ou Kick) e preencha `canais`. Rode `postiz integrations:list` e ponha o id de cada rede em `redes` (deixe vazio o que o usuário não quiser).
4. **Regras de cada rede:** `node <motor>/postar.mjs --conferir`. Leia as `rules` e os campos obrigatórios de cada rede e complete `ajustes` no `automatico.json` (o Postiz descarta em silêncio o que não se aplica e recusa o que falta). No TikTok, mantenha `content_posting_method: "DIRECT_POST"`; `"UPLOAD"` só deixa o vídeo na caixa de entrada do app.
5. **Teste sem postar:** `node <motor>/vigia-lives.mjs --uma-vez CAMINHO/DE/UM/VIDEO.mp4 --sem-postar`. Confira o corte gerado com o usuário.
6. **Ligar:** o usuário deixa rodando num terminal: `node ~/.maquina-cortes-gta/engine/scripts/vigia-lives.mjs`. Para subir junto com o computador: Windows, Agendador de Tarefas ("ao fazer logon"); macOS/Linux, `npx pm2 start <caminho>/vigia-lives.mjs --name vigia && npx pm2 save`.
7. **Pausar:** criar o arquivo `~/.maquina-cortes-gta/PAUSAR` (ou `"pausado": true`). **Parar:** Ctrl+C. **Ver o que aconteceu:** `~/.maquina-cortes-gta/automatico.log`.

Ajustes no `automatico.json` (relido a cada volta, sem reiniciar): `notaMinima` (7), `maxCortesPorBloco` (2), `maxPostsPorDia` (6), `minutosEntrePosts` (45), `blocoSegundos` (900), `hashtags`, `creditar` (põe "Créditos: canal" na legenda), `bottom` (link ou arquivo da metade de baixo), `apagarBrutos` (apaga a gravação bruta depois de processar), `claudeArgs` (permissões do Claude Code no modo `-p`).

Avise o usuário, uma vez, em poucas linhas: o computador precisa ficar ligado durante as lives; cada bloco usa o Claude Code e uma live de 1080p ocupa alguns GB por hora (o bruto é apagado depois); cortar a live de outra pessoa sem permissão pode gerar strike, então vale o OK do streamer.

## Regras

- Estilo: metade de cima o streamer (jump cuts com zoom), metade de baixo o vídeo; legenda palavra por palavra na divisa, caixa alta, palavra falada em amarelo; marca d'água no canto superior direito; final "Seguir". Detalhes em `references/estilo-metade-metade.md` e `references/estilo-referencias.md`.
- Não mude a marca d'água nem peça a logo de novo depois da primeira vez.
- Cada execução é independente: não reaproveite `cuts.json` de outro vídeo.
- Não invente fala: a legenda é o que a pessoa disse.
- Se algo falhar, veja `references/problemas.md`.
