# Problemas comuns

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| `ffmpeg: false` no `--check` | FFmpeg fora do PATH | Windows: `winget install Gyan.FFmpeg` · macOS: `brew install ffmpeg` · Linux: `apt install ffmpeg`. Abra um terminal novo depois. |
| `ytdlp: false` | yt-dlp não instalado | Windows: `winget install yt-dlp` · macOS: `brew install yt-dlp` · Linux: `pipx install yt-dlp`. Sem ele, só vale arquivo de vídeo. |
| yt-dlp: `HTTP Error 429` | O YouTube limitou as requisições | Espere alguns minutos e tente de novo. Se continuar, peça o arquivo de vídeo. |
| yt-dlp: `Sign in to confirm your age` | Vídeo com restrição de idade | Baixe o vídeo no navegador (logado) e passe o arquivo para a skill. Usar `--cookies-from-browser` dá acesso ao seu login: só faça se você quiser. |
| As pausas não foram cortadas | A live tem música ou som de jogo por baixo, então nada fica abaixo de -35 dB | Normal em live e react. Ponha `"silencioDb": -28` no `config.json` e transcreva de novo. Gagueira e "é..." não são cortados. |
| Câmera do streamer borrada | Origem em 720p e câmera pequena (live com várias câmeras) | Use uma origem com o streamer em plano grande, ou baixe em resolução maior. |
| yt-dlp: `Requested format is not available` | O vídeo não tem formato combinado | Use `-f "bv*+ba/b"` com `--merge-output-format mp4` (como no `SKILL.md`). Não filtre por `height`: em vídeo vertical a altura é a maior medida. |
| `npm install` falha | Sem internet ou versão antiga do Node | Use Node 18+ (de preferência 22+) e rode `node scripts/setup.mjs` de novo. |
| whisper.cpp não instala (macOS/Linux) | Ele é compilado na máquina | Instale as ferramentas de compilação (`xcode-select --install` no macOS, `build-essential` no Linux) e rode o setup de novo. |
| `Model ... does not exist` | O modelo não foi baixado | Rode `node scripts/setup.mjs`; o modelo fica em `~/.maquina-cortes-gta/whisper.cpp/`. |
| Legenda errada em português | Modelo pequeno demais | Em `~/.maquina-cortes-gta/config.json`, troque `whisperModel` para `medium` e rode o setup (baixa mais arquivos). |
| Legenda fora de sincronia | Vídeo de origem com taxa de quadros variável | Converta antes: `ffmpeg -i ARQ -vf fps=30 -c:a aac work/source.mp4`. |
| Rosto cortado na metade de cima | Streamer fora do centro | Ajuste `focus` no `cuts.json`. |
| O render demora | Remotion renderiza no seu computador | É normal; o 1º render também baixa o Chrome headless. |
| Corte sem som da pessoa | O arquivo de origem não tem áudio | Confira com `ffprobe -show_streams work/source.mp4`. |
| `motorAtualizado: false` no `--check` | A skill foi atualizada e o motor ainda tem os scripts antigos | Rode `node <skill>/scripts/setup.mjs` (só copia os arquivos novos; reinstala dependências se mudaram). |
| `mais-reproduzido.mjs` diz que não há gráfico | Vídeo novo ou com poucas visualizações; o YouTube não mostra o gráfico | Siga só pela transcrição. |
| `conferir-cortes.mjs` aponta "gancho não está no começo" | O `start` está antes ou depois da frase do gancho | Veja o segundo exato com `transcript-text.mjs --de X --ate Y --palavras` e ajuste o `start`. |
| Imagem ignorada no build | Arquivo não existe, a busca não trouxe nada ou a imagem cai depois do fim do corte (pausas removidas encurtam o corte) | Confira o caminho e o `at` (em segundos do vídeo de origem). |
| Um corte falhou e os outros não | Erro só naquele corte | Refaça só ele: `node <motor>/build.mjs work . ID_DO_CORTE`. |
| Vigia: "Falta claude" ou "Falta postiz" | O programa não está instalado ou não está no PATH | Claude Code: instale e abra uma vez. Postiz: `npm install -g postiz`. Abra um terminal novo. |
| Vigia não detecta a live | Link do canal errado, ou a live é agendada e ainda não começou | Use o link do canal (`youtube.com/@canal`, `twitch.tv/canal`); o vigia confere a cada 2 min. Teste: `yt-dlp --print live_status LINK/live`. |
| Vigia: "o Claude Code falhou" | Falta permissão no modo `-p` ou o login expirou | Abra o Claude Code uma vez para conferir o login; ajuste `claudeArgs` no `automatico.json`. |
| Post "agendado" mas não aparece no TikTok | `content_posting_method` em `"UPLOAD"` | Use `"DIRECT_POST"` em `ajustes.tiktok`. |
| Postiz recusa o post | Falta um campo obrigatório da rede | `node postar.mjs --conferir` e complete `ajustes` no `automatico.json`. |
| "N blocos na fila" no log | O computador processa mais devagar que a live | Aumente `blocoSegundos`, use o modelo `base` do whisper ou deixe a fila esvaziar depois da live. |
| "limite de posts por dia atingido" | `maxPostsPorDia` alcançado | Normal. O corte fica salvo no disco; suba o limite se quiser. |
