# Estilo de referência dos cortes

Resumo de três vídeos de referência (um de narração com imagens e dois cortes de streamer), medidos com ffmpeg (cortes de cena, loudness). Cada item diz se **já está no template** ou se ainda é **manual**.

## Base do corte de streamer
- Jump cuts de ~1,5–2,8 s por plano, só com mudança de zoom, **sem swoosh**. *(Template: sim.)*
- Legenda grande na divisa, caixa alta, palavra em destaque. *(Template: sim; a cor muda com `corPalavra`. Legenda por frase inteira ainda não existe.)*
- Marca do canal pequena no canto e nada mais fixo na tela. *(Template: sim.)*
- **Três layouts alternando conforme a fala** (streamer em tela cheia, b-roll em tela cheia, tela dividida). *(Template: só tela dividida. Manual.)*

## Virada de seção = swoosh
- Só em mudança de assunto, entrada de popup importante ou menção a um console. *(Template: `turns`.)*
- **Menção a PlayStation/PS5/Xbox:** marque o segundo em `turns` e ponha uma `foto` do console por ~1,5 s. *(Template: sim.)*
- **Logo do jogo sobre o streamer** na 1ª menção ao GTA 6. *(Template: `tipo: "logo"`, PNG transparente.)*

## Popups com imagem real
Capa/arte oficial ao falar o nome do jogo; ícone da Rockstar ao dizer "Rockstar"; mapa ao falar de mapa; capas de GTA 5, GTA 4 e Red Dead 2 ao citá-los, sem escrever "3× maior" na tela (a legenda basta); comparação **"GTA 5 | GTA 6" com os dois mapas lado a lado** *(template: `tipo: "comparar"`)*. Não usar mapa vazado.

## Som
- Voz na frente. Sem música (ou bem baixa, ≈ −33 LUFS).
- **Poucos efeitos:** impacto no quadro 0, swoosh nas viradas, pop em cada popup; **menos de 15 por 35 s**. *(Template: sim, com limite automático.)*
- Mix final ≈ **−14 LUFS**, pico ≤ −1 dBTP. *(Ainda manual: normalize depois com `ffmpeg -i corte.mp4 -af loudnorm=I=-14:TP=-1 -c:v copy saida.mp4`.)*

## Ritmo e silêncio
- **Pausa entre frases > 0,3 s vira 0,2 s**; pausa dentro da frase fica. *(Template: sim.)*

## Final
**"Seguir → Seguindo"** nos últimos ~3 s, com a logo e o nome do canal (sem @). *(Template: sim.)*

## Escolha do trecho
Para vídeo do YouTube, o pico do gráfico **"Mais reproduzidos"** é candidato forte. *(Template: `mais-reproduzido.mjs`, pelo yt-dlp, sem navegador.)*
