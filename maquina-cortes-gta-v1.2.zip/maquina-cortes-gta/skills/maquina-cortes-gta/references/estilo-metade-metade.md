# Estilo "metade streamer, metade vídeo"

O visual está em `template/src/SplitCut.jsx`. Este arquivo diz o que cada parte faz e o que dá para mudar.

## Layout (1080×1920, 30 fps)

| Região | O que tem |
|---|---|
| **Metade de cima** (0–960 px) | O vídeo de origem (o streamer), cortado para preencher a metade. Enquadramento por `focus` (`x`, `y` de 0 a 100; padrão `50, 35`) ou por `crop` (região em pixels da origem). |
| **Metade de baixo** (960–1920 px) | O segundo vídeo (gameplay, trailer ou B-roll), mudo, em loop se for mais curto que o corte. Cada corte começa num ponto diferente dele. |
| **Divisa** (y = 960) | Degradê escuro de ~340 px e a **legenda** por cima. |
| **Canto superior direito** (topo 150 px, margem 40 px) | **Marca d'água:** logo circular e o nome do perfil ao lado. |
| **Últimos 3 s** (metade de baixo) | **Final "Seguir → Seguindo"**: pílula branca com a logo e o nome; o cursor clica em "Seguir" (laranja) aos ~1,25 s e ele vira "Seguindo ✓". |

## Legenda

- Palavra por palavra, **1 a 3 palavras** por vez (até ~20 letras; quebra em pausa maior que 0,6 s e em fim de frase).
- Caixa alta, Montserrat Black, 96 px, branca com contorno preto. A **palavra falada fica amarela** (`#FFD400`) e cresce um pouco ao entrar; entre uma palavra e outra, a última dita continua acesa.
- O texto é o que foi falado (whisper.cpp); só muda a caixa. Vírgula e ponto e vírgula no fim da palavra saem.

## Cortes e ritmo

- **Início e fim** encaixados nas palavras: ~0,15 s antes da 1ª, ~0,25 s depois da última.
- **Pausas:** entre frases, acima de 0,3 s fica com 0,2 s. Dentro da frase, só sai hesitação acima de 0,8 s. Nenhum trecho com fala é descartado.
- **Jump cuts:** a cada ~2,8 s, no começo de uma palavra. O zoom alterna entre 100% e 107%, seco. O 1º plano entra com um punch-in curto.
- **Viradas de seção (`turns`):** punch-in, flash branco curto e swoosh.
- A fala do streamer é o áudio do corte; o vídeo de baixo não tem som.

## Popups

- `foto`: cartão com borda branca, entra com escala 0,9 → 1 e balanço; sai com fade.
- `logo`: PNG transparente, sem cartão, vem de 0,35× até 1× acelerando e sai passando da tela (1,6×).
- `comparar`: duas imagens lado a lado com rótulo embaixo; a 2ª entra logo depois da 1ª.

## O que o usuário pode pedir (config.json em `~/.maquina-cortes-gta`)

| Pedido | Chave |
|---|---|
| Outra cor da palavra falada | `"corPalavra": "#C6FF00"` |
| Efeitos mais altos ou mais baixos | `"sfxGain": 0.6` |
| Pausas mais ou menos agressivas | `"pausaMinima"`, `"pausaFica"`, `"pausaLongaNaFrase"` (segundos) |
| Sem o final "Seguir" | `"finalSeguir": false` |
| Live com música por baixo (pausas não são achadas) | `"silencioDb": -28` (depois transcreva de novo) |

Outras mudanças (tamanho da legenda, posição da marca d'água): edite `template/src/SplitCut.jsx` da skill e rode o `setup.mjs`, que leva a mudança para o motor.
