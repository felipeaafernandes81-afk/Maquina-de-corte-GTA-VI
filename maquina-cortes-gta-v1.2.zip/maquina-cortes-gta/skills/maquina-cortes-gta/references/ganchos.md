# Como escolher os cortes pelo gancho

Você tem a transcrição (palavras com tempo) e, às vezes, os picos do "mais reproduzido". Escolha por **o que a frase faz com quem ouve**, não pelo assunto em si. Quem rola o feed decide em ~2 s se fica.

## Processo em 4 passos

1. **Mapa de assuntos.** Leia a transcrição inteira em blocos e anote: `[minuto] assunto: frase mais forte do bloco`.
2. **Candidatos.** Para cada bloco, separe até 2 frases que poderiam abrir um corte. Os trechos marcados `[PICO n]` entram sempre como candidatos: o público já mostrou que volta neles.
3. **Nota.** Dê a nota (tabela abaixo) a cada candidato. Para cada um, ache o **payoff** (a frase que responde o gancho). Sem payoff dentro de ~60 s, descarte.
4. **Seleção.** Fique com os 3 a 5 de maior nota, um por assunto, sem dois ganchos parecidos. Rode `conferir-cortes.mjs` e corrija.

## O que torna uma frase um bom gancho (nota 0 a 10)

| Critério | Pontos | Como reconhecer na transcrição |
|---|---:|---|
| **Abre uma lacuna** de curiosidade | 0–3 | Levanta uma pergunta ou tensão que só o resto do corte responde ("o erro que quase todo mundo vai cometer…"). Vale mais quando não entrega a resposta de cara. |
| **Fato específico** | 0–2 | Número, nome, data, comparação ("35 minutos", "a soma do GTA 4, GTA 5 e Red Dead 2"). |
| **Conflito ou opinião forte** | 0–2 | Discorda, reclama, se surpreende, dá um veredito. |
| **Entra direto** | 0–1 | A 1ª frase já é o ponto. Sem "então, galera", "bom, vamos lá". |
| **Tem payoff dentro do corte** | 0–1 | A resposta chega antes de acabar. |
| **Se entende sozinho** | 0–1 | Quem não viu o resto entende do que se fala em 5 s. |

- **9–10:** gancho forte. **6–8:** bom. **Abaixo de 6:** descarte, mesmo com assunto bom.
- **Bônus de desempate:** o trecho cai num pico do "mais reproduzido".
- **Penalize:** promessa que o corte não cumpre; trecho que depende de contexto anterior ("como eu falei", "isso aí que ele disse"); piada interna; pronome sem referência na 1ª frase ("ele", "isso") quando o nome só vem depois.

## Teste dos 2 segundos

Leia só as **primeiras 5 a 7 palavras** do corte (o `conferir-cortes.mjs` mostra). Se elas sozinhas não dão vontade de ouvir o resto, o corte começa no lugar errado. Às vezes o gancho está **uma frase depois** do que parecia: a reação ("Mano, não acredito") vem antes, e a frase forte vem logo em seguida.

## Assuntos e ganchos diferentes

- Cada corte sai de **um bloco diferente** do mapa de assuntos.
- Dois cortes **não** abrem com a mesma ideia nem com a mesma estrutura de frase. Se dois ganchos forem parecidos, fique com o de maior nota.
- Espalhe os cortes ao longo do vídeo.

## Onde começar e terminar

- **Início:** o segundo da 1ª palavra do gancho (veja com `transcript-text.mjs --palavras`). O build já recua ~0,15 s.
- **Fim:** a última palavra do payoff. O build já estica ~0,25 s. Não deixe frase pela metade nem "né?" solto.
- **Duração final (sem pausas):** 20 a 60 s. Um assunto excelente pode chegar a ~75 s.

## Formatos de gancho que funcionam bem em corte de conversa

- **Afirmação surpreendente + consequência:** "Isso aqui vai ser o maior problema do lançamento."
- **Comparação com o que o público conhece:** "É a soma de três mapas."
- **Pergunta direta ao espectador:** "Você sabia que…?"
- **Reação forte ao vivo:** quando a pessoa se surpreende ou discorda, a frase seguinte costuma ser o gancho.
- **Número ou nome na primeira frase.**

## Título sugerido

Um por corte, até ~40 caracteres, com o fato ou a tensão do gancho, sem entregar o payoff e sem prometer o que o corte não mostra. Grave em `"titulo"` no `cuts.json`.

## O que NÃO fazer

- Não escolha o trecho só porque é engraçado fora de contexto.
- Não invente gancho: a legenda é o que a pessoa falou.
- Não mude o sentido ao encurtar; as pausas são removidas, as frases não.
